import AsyncStorage from '@react-native-async-storage/async-storage';
import { create } from 'zustand';
import type { Course, Extra, Mark, MarkStatus, Slot, Weekday } from '@/types';
import { mondayOf, todayKey } from '@/lib/date';
import {
  buildSchedule,
  type Schedule,
  sessionKey,
  weekdayTemplate,
} from '@/lib/schedule';
import { DEFAULT_TARGET } from '@/lib/stats';
import { nextColor } from '@/theme';

const STORAGE_KEY = 'bunkbank-v2';

export type Persisted = {
  courses: Course[];
  semesterStart: string;
  holidays: string[];
  extras: Extra[];
  cancellations: string[];
  marks: Record<string, Mark>;
  /** Report subject label -> course id, remembered between imports. */
  subjectMap: Record<string, string>;
  target: number;
  lastReportAsOf?: string;
  onboarded: boolean;
};

const EMPTY: Persisted = {
  courses: [],
  semesterStart: mondayOf(todayKey()),
  holidays: [],
  extras: [],
  cancellations: [],
  marks: {},
  subjectMap: {},
  target: DEFAULT_TARGET,
  onboarded: false,
};

type Store = Persisted & {
  hydrated: boolean;
  schedule: Schedule;

  hydrate: () => Promise<void>;
  reset: () => Promise<void>;

  setSemesterStart: (date: string) => void;
  setTarget: (t: number) => void;
  setOnboarded: (v: boolean) => void;

  addCourse: (input: {
    name: string;
    code?: string;
    slots: Slot[];
    totalLectures: number;
  }) => string;
  updateCourse: (id: string, patch: Partial<Course>) => void;
  removeCourse: (id: string) => void;
  replaceCourses: (courses: Course[]) => void;

  mark: (key: string, status: MarkStatus) => void;
  unmark: (key: string) => void;
  applyReportMarks: (
    marks: Record<string, Mark>,
    extras: Extra[],
    totalAdjustments: Record<string, number>,
    asOf: string
  ) => void;
  setSubjectMap: (map: Record<string, string>) => void;

  postpone: (key: string) => void;
  unpostpone: (key: string) => void;
  toggleHoliday: (date: string) => void;
  addExtra: (input: Omit<Extra, 'id'>) => void;
  removeExtra: (id: string) => void;
  cloneWeekday: (date: string, sourceDay: Weekday) => number;
  removeClone: (cloneId: string) => void;
};

function rebuild(state: Persisted): Schedule {
  return buildSchedule({
    courses: state.courses,
    semesterStart: state.semesterStart,
    holidays: state.holidays,
    extras: state.extras,
    cancellations: state.cancellations,
  });
}

let saveTimer: ReturnType<typeof setTimeout> | null = null;

function persist(state: Persisted) {
  if (saveTimer) clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    const snapshot: Persisted = {
      courses: state.courses,
      semesterStart: state.semesterStart,
      holidays: state.holidays,
      extras: state.extras,
      cancellations: state.cancellations,
      marks: state.marks,
      subjectMap: state.subjectMap,
      target: state.target,
      lastReportAsOf: state.lastReportAsOf,
      onboarded: state.onboarded,
    };
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(snapshot)).catch(() => {});
  }, 250);
}

export const useStore = create<Store>((set, get) => {
  /** Every mutation goes through here so the schedule and disk stay in step. */
  const commit = (patch: Partial<Persisted>) => {
    set((prev) => {
      const next = { ...prev, ...patch } as Persisted;
      persist(next);
      return { ...patch, schedule: rebuild(next) } as Partial<Store>;
    });
  };

  return {
    ...EMPTY,
    hydrated: false,
    schedule: rebuild(EMPTY),

    hydrate: async () => {
      try {
        const raw = await AsyncStorage.getItem(STORAGE_KEY);
        const loaded: Persisted = raw ? { ...EMPTY, ...JSON.parse(raw) } : EMPTY;
        set({ ...loaded, hydrated: true, schedule: rebuild(loaded) });
      } catch {
        set({ ...EMPTY, hydrated: true, schedule: rebuild(EMPTY) });
      }
    },

    reset: async () => {
      await AsyncStorage.removeItem(STORAGE_KEY);
      set({ ...EMPTY, hydrated: true, schedule: rebuild(EMPTY) });
    },

    setSemesterStart: (date) => commit({ semesterStart: date }),
    setTarget: (target) => commit({ target }),
    setOnboarded: (onboarded) => commit({ onboarded }),

    addCourse: ({ name, code, slots, totalLectures }) => {
      const id = `c_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
      const courses = get().courses;
      commit({
        courses: [
          ...courses,
          { id, name, code, slots, totalLectures, color: nextColor(courses.length) },
        ],
      });
      return id;
    },

    updateCourse: (id, patch) =>
      commit({
        courses: get().courses.map((c) => (c.id === id ? { ...c, ...patch } : c)),
      }),

    removeCourse: (id) => {
      const marks = { ...get().marks };
      for (const key of Object.keys(marks)) {
        if (key.split('|')[1] === id) delete marks[key];
      }
      commit({
        courses: get().courses.filter((c) => c.id !== id),
        extras: get().extras.filter((e) => e.courseId !== id),
        cancellations: get().cancellations.filter((k) => k.split('|')[1] !== id),
        marks,
      });
    },

    replaceCourses: (courses) => commit({ courses }),

    mark: (key, status) =>
      commit({
        marks: { ...get().marks, [key]: { status, source: 'user', at: new Date().toISOString() } },
      }),

    unmark: (key) => {
      const marks = { ...get().marks };
      delete marks[key];
      commit({ marks });
    },

    applyReportMarks: (newMarks, extras, totalAdjustments, asOf) => {
      const state = get();
      const courses = state.courses.map((c) =>
        totalAdjustments[c.id]
          ? { ...c, totalLectures: c.totalLectures + totalAdjustments[c.id] }
          : c
      );
      const existingIds = new Set(state.extras.map((e) => e.id));
      commit({
        courses,
        extras: [...state.extras, ...extras.filter((e) => !existingIds.has(e.id))],
        marks: { ...state.marks, ...newMarks },
        lastReportAsOf: asOf,
      });
    },

    setSubjectMap: (subjectMap) => commit({ subjectMap }),

    postpone: (key) => {
      if (get().cancellations.includes(key)) return;
      const marks = { ...get().marks };
      delete marks[key]; // a lecture that did not happen carries no attendance
      commit({ cancellations: [...get().cancellations, key], marks });
    },

    unpostpone: (key) =>
      commit({ cancellations: get().cancellations.filter((k) => k !== key) }),

    toggleHoliday: (date) => {
      const holidays = get().holidays;
      const on = holidays.includes(date);
      const marks = { ...get().marks };
      if (!on) {
        for (const key of Object.keys(marks)) {
          if (key.startsWith(`${date}|`)) delete marks[key];
        }
      }
      commit({
        holidays: on ? holidays.filter((d) => d !== date) : [...holidays, date],
        marks,
      });
    },

    addExtra: (input) =>
      commit({
        extras: [
          ...get().extras,
          { ...input, id: `x_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}` },
        ],
      }),

    removeExtra: (id) => {
      const extra = get().extras.find((e) => e.id === id);
      const marks = { ...get().marks };
      if (extra) delete marks[sessionKey(extra.date, extra.courseId, extra.start)];
      commit({ extras: get().extras.filter((e) => e.id !== id), marks });
    },

    /**
     * Runs another weekday's whole timetable on this date. Each copied lecture
     * is an extra, so it spends budget early and the semester tail shortens by
     * exactly the number of lectures copied.
     */
    cloneWeekday: (date, sourceDay) => {
      const state = get();
      const template = weekdayTemplate(state.courses, sourceDay);
      const taken = new Set(state.extras.filter((e) => e.date === date).map((e) => e.start));
      const cloneId = `cl_${Date.now().toString(36)}`;

      const added: Extra[] = template
        .filter((t) => !taken.has(t.start))
        .map((t, i) => ({
          id: `${cloneId}_${i}`,
          date,
          courseId: t.courseId,
          start: t.start,
          end: t.end,
          room: t.room,
          cloneId,
          sourceDay,
        }));

      if (added.length) commit({ extras: [...state.extras, ...added] });
      return added.length;
    },

    removeClone: (cloneId) => {
      const state = get();
      const going = state.extras.filter((e) => e.cloneId === cloneId);
      const marks = { ...state.marks };
      for (const e of going) delete marks[sessionKey(e.date, e.courseId, e.start)];
      commit({ extras: state.extras.filter((e) => e.cloneId !== cloneId), marks });
    },
  };
});

export function useCourse(id: string | undefined): Course | undefined {
  return useStore((s) => s.courses.find((c) => c.id === id));
}

export function courseMap(courses: Course[]): Map<string, Course> {
  return new Map(courses.map((c) => [c.id, c]));
}
