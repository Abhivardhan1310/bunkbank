import type {
  Course,
  Extra,
  Mark,
  ReconcileResult,
  ReportParse,
  ReportRow,
  Session,
} from '@/types';
import { timeSort } from './date';
import type { Schedule } from './schedule';
import { sessionKey } from './schedule';

/** Loose match so "ADV. FIN. MGMT (FE)" finds "Advanced Financial Management (FE)". */
function normalise(s: string): string {
  return s
    .toLowerCase()
    .replace(/\(.*?\)/g, ' ')
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
}

function initials(s: string): string {
  return normalise(s)
    .split(' ')
    .filter((w) => w.length > 2)
    .map((w) => w[0])
    .join('');
}

/**
 * Resolves a report's subject label to a course. Explicit user mappings always
 * win; code matches beat name matches; anything unresolved is handed back for
 * the mapping screen rather than guessed at.
 */
export function resolveCourse(
  row: ReportRow,
  courses: Course[],
  mapping: Record<string, string>
): string | null {
  const label = row.code || row.subject;
  const mapped = mapping[label] ?? mapping[row.subject];
  if (mapped && courses.some((c) => c.id === mapped)) return mapped;

  if (row.code) {
    const byCode = courses.find(
      (c) => c.code && normalise(c.code) === normalise(row.code!)
    );
    if (byCode) return byCode.id;
  }

  const target = normalise(row.subject);
  const exact = courses.find((c) => normalise(c.name) === target);
  if (exact) return exact.id;

  const prefix = courses.filter(
    (c) => normalise(c.name).startsWith(target) || target.startsWith(normalise(c.name))
  );
  if (prefix.length === 1) return prefix[0].id;

  const abbrev = courses.filter((c) => initials(c.name) === initials(row.subject));
  if (abbrev.length === 1) return abbrev[0].id;

  return null;
}

export function unresolvedSubjects(
  parse: ReportParse,
  courses: Course[],
  mapping: Record<string, string>
): string[] {
  const out = new Set<string>();
  for (const row of parse.rows) {
    if (!resolveCourse(row, courses, mapping)) out.add(row.code || row.subject);
  }
  return [...out];
}

export type ReconcilePlan = {
  result: ReconcileResult;
  /** Marks to write, all tagged as coming from the report. */
  marks: Record<string, Mark>;
  /** Lectures the report knows about that were never scheduled. */
  newExtras: Extra[];
  /** Per-course bumps to totalLectures, so the report wins on totals. */
  totalAdjustments: Record<string, number>;
};

/**
 * Report rows are matched against scheduled lectures date-by-date and course-by-
 * course. Within a date, rows with a printed time match the nearest-in-time
 * lecture; rows without one are matched in printed order.
 *
 * Three rules, in the order they matter:
 *
 *  1. Where the report has a row, the report wins — even over a swipe.
 *  2. Where the report has no row for a past lecture, the swipe stands. Faculty
 *     mark late, and a silent wipe of your own record would be worse than a
 *     stale one.
 *  3. Where the report has a row for a lecture that was never scheduled, the
 *     lecture is inserted and the course total grows. The report is the
 *     authority on how many lectures actually happened.
 */
export function reconcile(
  parse: ReportParse,
  courses: Course[],
  schedule: Schedule,
  existingMarks: Record<string, Mark>,
  mapping: Record<string, string>
): ReconcilePlan {
  const marks: Record<string, Mark> = {};
  const newExtras: Extra[] = [];
  const totalAdjustments: Record<string, number> = {};
  const at = new Date().toISOString();

  let overwritten = 0;
  let confirmed = 0;
  let inserted = 0;

  // Group rows by date + course so same-day repeats can be matched in order.
  const groups = new Map<string, ReportRow[]>();
  const unmatchedSubjects = new Set<string>();

  for (const row of parse.rows) {
    const courseId = resolveCourse(row, courses, mapping);
    if (!courseId) {
      unmatchedSubjects.add(row.code || row.subject);
      continue;
    }
    const gk = `${row.date}|${courseId}`;
    const list = groups.get(gk) ?? [];
    list.push(row);
    groups.set(gk, list);
  }

  const claimed = new Set<string>();

  for (const [gk, rows] of groups) {
    const [date, courseId] = gk.split('|');
    const scheduled = (schedule.byDate.get(date) ?? [])
      .filter((s) => s.courseId === courseId)
      .sort((a, b) => timeSort(a.start, b.start));

    const timed = rows.filter((r) => r.time).sort((a, b) => timeSort(a.time!, b.time!));
    const untimed = rows.filter((r) => !r.time);

    const available = [...scheduled];

    const take = (row: ReportRow): Session | undefined => {
      if (available.length === 0) return undefined;
      if (!row.time) return available.shift();
      let bestIdx = 0;
      let bestGap = Infinity;
      for (let i = 0; i < available.length; i++) {
        const gap = Math.abs(minutes(available[i].start) - minutes(row.time));
        if (gap < bestGap) {
          bestGap = gap;
          bestIdx = i;
        }
      }
      return available.splice(bestIdx, 1)[0];
    };

    for (const row of [...timed, ...untimed]) {
      const session = take(row);

      if (session) {
        claimed.add(session.key);
        const prev = existingMarks[session.key];
        if (prev && prev.status !== row.status) overwritten++;
        else if (prev) confirmed++;
        marks[session.key] = { status: row.status, source: 'report', at };
        continue;
      }

      // The report knows about a lecture we never scheduled.
      const start = row.time ?? nextFreeSlot(date, courseId, schedule, newExtras);
      const key = sessionKey(date, courseId, start);
      if (claimed.has(key) || marks[key]) continue;

      newExtras.push({
        id: `rpt_${date}_${courseId}_${start}`,
        date,
        courseId,
        start,
        end: addHour(start),
        fromReport: true,
      });
      marks[key] = { status: row.status, source: 'report', at };
      totalAdjustments[courseId] = (totalAdjustments[courseId] ?? 0) + 1;
      inserted++;
      claimed.add(key);
    }
  }

  // Rule 2: count what we deliberately left alone, so the summary can say so.
  let keptOwn = 0;
  for (const s of schedule.sessions) {
    if (s.date > parse.asOf) continue;
    if (claimed.has(s.key)) continue;
    if (existingMarks[s.key]) keptOwn++;
  }

  return {
    result: {
      asOf: parse.asOf,
      overwritten,
      confirmed,
      inserted,
      unmatchedSubjects: [...unmatchedSubjects],
      keptOwn,
    },
    marks,
    newExtras,
    totalAdjustments,
  };
}

function minutes(hhmm: string): number {
  const [h, m] = hhmm.split(':').map(Number);
  return h * 60 + m;
}

function addHour(hhmm: string): string {
  const [h, m] = hhmm.split(':').map(Number);
  const nh = (h + 1) % 24;
  return `${`${nh}`.padStart(2, '0')}:${`${m}`.padStart(2, '0')}`;
}

/** Places an untimed inserted lecture after whatever already sits on that day. */
function nextFreeSlot(
  date: string,
  courseId: string,
  schedule: Schedule,
  pending: Extra[]
): string {
  const used = new Set<string>();
  for (const s of schedule.byDate.get(date) ?? []) used.add(s.start);
  for (const e of pending) if (e.date === date) used.add(e.start);

  let candidate = '09:00';
  for (const s of [...used].sort(timeSort)) {
    if (s >= candidate) candidate = addHour(s);
  }
  while (used.has(candidate)) candidate = addHour(candidate);
  return candidate;
}

export function summarise(r: ReconcileResult): string {
  const bits: string[] = [];
  if (r.overwritten) bits.push(`${r.overwritten} changed`);
  if (r.confirmed) bits.push(`${r.confirmed} confirmed`);
  if (r.inserted) bits.push(`${r.inserted} added`);
  if (r.keptOwn) bits.push(`${r.keptOwn} kept from your own marks`);
  return bits.length ? bits.join(' · ') : 'Nothing to change';
}
