import type {
  CancelledSession,
  Course,
  Extra,
  Session,
  Weekday,
} from '@/types';
import { addDays, timeSort, todayKey, weekdayOf } from './date';

export const HORIZON_DAYS = 500;

export function sessionKey(date: string, courseId: string, start: string): string {
  return `${date}|${courseId}|${start}`;
}

export type ScheduleInput = {
  courses: Course[];
  semesterStart: string;
  holidays: string[];
  extras: Extra[];
  /** Session keys that were postponed — they run no lecture and spend no budget. */
  cancellations: string[];
};

export type Schedule = {
  sessions: Session[];
  byDate: Map<string, Session[]>;
  byCourse: Map<string, Session[]>;
  cancelledByDate: Map<string, CancelledSession[]>;
  /** Last scheduled date per course — the tail the budget model pushes against. */
  lastDateByCourse: Map<string, string>;
  /** Last teaching day across every course. There is no user-set semester end date. */
  semesterEnd?: string;
  /** Courses whose budget could not be placed inside the horizon. */
  overflow: string[];
  /** Per course, lectures that ran after the planned total was used up. */
  beyondPlan: Map<string, number>;
};

/**
 * Builds the whole semester from a fixed per-course lecture budget.
 *
 * Everything the app can do to a day is a *timing* change, never a *count*
 * change, so the semester total is invariant:
 *
 *   - postpone a lecture  -> budget unspent that day -> one more lands at the tail
 *   - mark a day a holiday -> same, for every lecture on it
 *   - add an extra lecture -> budget spent early -> the tail loses one
 *   - clone a weekday      -> several extras at once -> the tail loses that many
 *
 * That is why nothing here ever edits `course.totalLectures`. Only an official
 * report is allowed to move that number (see lib/report.ts).
 */
export function buildSchedule(input: ScheduleInput): Schedule {
  const { courses, semesterStart, holidays, extras, cancellations } = input;

  const budget = new Map<string, number>();
  for (const c of courses) budget.set(c.id, Math.max(0, c.totalLectures));

  const holidaySet = new Set(holidays);
  const cancelSet = new Set(cancellations);
  const courseById = new Map(courses.map((c) => [c.id, c]));

  const extrasByDate = new Map<string, Extra[]>();
  for (const e of extras) {
    const list = extrasByDate.get(e.date) ?? [];
    list.push(e);
    extrasByDate.set(e.date, list);
  }

  const sessions: Session[] = [];
  /** Lectures that ran even though the planned budget was spent. */
  const beyondPlan = new Map<string, number>();
  /**
   * Two lectures of the same course at the same time on the same day used to
   * collide on one key, which made marking one mark both. Keys stay stable for
   * everything that does not collide, so marks recorded earlier still match.
   */
  const usedKeys = new Set<string>();
  const byDate = new Map<string, Session[]>();
  const byCourse = new Map<string, Session[]>();
  const cancelledByDate = new Map<string, CancelledSession[]>();
  const lastDateByCourse = new Map<string, string>();

  const remaining = () => {
    let n = 0;
    for (const v of budget.values()) n += v;
    return n;
  };

  // The walk must not stop the moment the planned lectures are used up, or an
  // extra class dated after that point is never reached and silently disappears.
  let lastExtraDate = '';
  for (const e of extras) if (e.date > lastExtraDate) lastExtraDate = e.date;

  let date = semesterStart;
  for (
    let i = 0;
    i < HORIZON_DAYS && (remaining() > 0 || date <= lastExtraDate);
    i++, date = addDays(date, 1)
  ) {
    const dow = weekdayOf(date);
    const isHoliday = holidaySet.has(date);

    type Item = {
      courseId: string;
      start: string;
      end: string;
      room?: string;
      kind: 'regular' | 'extra';
      cloneId?: string;
      sourceDay?: Weekday;
    };
    const items: Item[] = [];

    if (!isHoliday) {
      for (const c of courses) {
        for (const s of c.slots) {
          if (s.day === dow) {
            items.push({
              courseId: c.id,
              start: s.start,
              end: s.end,
              room: s.room,
              kind: 'regular',
            });
          }
        }
      }
    }

    for (const e of extrasByDate.get(date) ?? []) {
      items.push({
        courseId: e.courseId,
        start: e.start,
        end: e.end,
        room: e.room,
        kind: 'extra',
        cloneId: e.cloneId,
        sourceDay: e.sourceDay,
      });
    }

    items.sort((a, b) => timeSort(a.start, b.start));

    for (const it of items) {
      const left = budget.get(it.courseId) ?? 0;

      // A regular weekly slot stops running once the course has had all its
      // planned lectures. An extra is a class that actually happened, so it is
      // always shown — dropping it silently was the bug that made added
      // lectures disappear and the course look finished.
      if (left <= 0 && it.kind === 'regular') continue;

      let key = sessionKey(date, it.courseId, it.start);
      if (usedKeys.has(key)) {
        let n = 2;
        while (usedKeys.has(`${key}#${n}`)) n++;
        key = `${key}#${n}`;
      }

      if (cancelSet.has(key)) {
        pushCancelled(cancelledByDate, {
          key,
          date,
          courseId: it.courseId,
          start: it.start,
          end: it.end,
          room: it.room,
          reason: 'postponed',
        });
        continue; // budget deliberately untouched
      }

      const total = courseById.get(it.courseId)?.totalLectures ?? 0;
      if (left > 0) {
        budget.set(it.courseId, left - 1);
      } else {
        beyondPlan.set(it.courseId, (beyondPlan.get(it.courseId) ?? 0) + 1);
      }
      usedKeys.add(key);

      const session: Session = {
        key,
        date,
        courseId: it.courseId,
        start: it.start,
        end: it.end,
        room: it.room,
        kind: it.kind,
        index: left > 0 ? total - (left - 1) : total + (beyondPlan.get(it.courseId) ?? 0),
        cloneId: it.cloneId,
        sourceDay: it.sourceDay,
      };

      sessions.push(session);
      pushTo(byDate, date, session);
      pushTo(byCourse, it.courseId, session);
      lastDateByCourse.set(it.courseId, date);
    }

    // Holidays still show what *would* have run, greyed out.
    if (isHoliday) {
      for (const c of courses) {
        if ((budget.get(c.id) ?? 0) <= 0) continue;
        for (const s of c.slots) {
          if (s.day !== dow) continue;
          pushCancelled(cancelledByDate, {
            key: sessionKey(date, c.id, s.start),
            date,
            courseId: c.id,
            start: s.start,
            end: s.end,
            room: s.room,
            reason: 'holiday',
          });
        }
      }
    }
  }

  const overflow: string[] = [];
  for (const [id, left] of budget) if (left > 0) overflow.push(id);

  let semesterEnd: string | undefined;
  for (const d of lastDateByCourse.values()) {
    if (!semesterEnd || d > semesterEnd) semesterEnd = d;
  }

  return {
    sessions,
    byDate,
    byCourse,
    cancelledByDate,
    lastDateByCourse,
    semesterEnd,
    overflow,
    beyondPlan,
  };
}

function pushTo<T>(map: Map<string, T[]>, key: string, value: T) {
  const list = map.get(key) ?? [];
  list.push(value);
  map.set(key, list);
}

function pushCancelled(
  map: Map<string, CancelledSession[]>,
  value: CancelledSession
) {
  pushTo(map, value.date, value);
}

export function sessionsOn(schedule: Schedule, date: string): Session[] {
  return schedule.byDate.get(date) ?? [];
}

export function cancelledOn(schedule: Schedule, date: string): CancelledSession[] {
  return schedule.cancelledByDate.get(date) ?? [];
}

/** The lecture a postponed one is replaced by: the course's new final lecture. */
export function tailOf(schedule: Schedule, courseId: string): Session | undefined {
  const list = schedule.byCourse.get(courseId);
  return list?.[list.length - 1];
}

/**
 * Where a postponement would land, computed against a schedule built *with*
 * that postponement applied. Used only to tell the user what happened.
 */
export function landingDate(after: Schedule, courseId: string): string | undefined {
  return after.lastDateByCourse.get(courseId);
}

/** Every distinct weekday that carries at least one lecture, for the day-clone picker. */
export function teachingWeekdays(courses: Course[]): Weekday[] {
  const set = new Set<Weekday>();
  for (const c of courses) for (const s of c.slots) set.add(s.day);
  return [...set].sort((a, b) => a - b);
}

/** The lecture list a weekday runs — the payload for "run Monday's timetable". */
export function weekdayTemplate(
  courses: Course[],
  day: Weekday
): { courseId: string; start: string; end: string; room?: string }[] {
  const out: { courseId: string; start: string; end: string; room?: string }[] = [];
  for (const c of courses) {
    for (const s of c.slots) {
      if (s.day === day) out.push({ courseId: c.id, start: s.start, end: s.end, room: s.room });
    }
  }
  return out.sort((a, b) => timeSort(a.start, b.start));
}

/**
 * Lectures of a course still unplaced — what is left to pull forward.
 * Zero means every lecture the course has is already on the calendar.
 */
export function plannedRemaining(
  schedule: Schedule,
  course: { id: string; totalLectures: number }
): number {
  const emitted = schedule.byCourse.get(course.id)?.length ?? 0;
  const beyond = schedule.beyondPlan.get(course.id) ?? 0;
  return Math.max(0, course.totalLectures - (emitted - beyond));
}

/** Lectures a course is owed back: postponed, or lost to a holiday. */
export function owedBack(schedule: Schedule, courseId: string): number {
  let n = 0;
  for (const list of schedule.cancelledByDate.values()) {
    for (const c of list) if (c.courseId === courseId) n++;
  }
  return n;
}

export function isPast(date: string): boolean {
  return date < todayKey();
}
