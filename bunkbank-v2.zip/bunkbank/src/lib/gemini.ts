import * as SecureStore from 'expo-secure-store';
import type { ReportParse, ReportRow, Weekday } from '@/types';

const KEY_SLOT = 'bunkbank.gemini.key';
const ENDPOINT = 'https://generativelanguage.googleapis.com/v1beta/models';
const MODEL = 'gemini-flash-latest';

export async function getApiKey(): Promise<string | null> {
  return SecureStore.getItemAsync(KEY_SLOT);
}

export async function setApiKey(key: string): Promise<void> {
  await SecureStore.setItemAsync(KEY_SLOT, key.trim());
}

export async function clearApiKey(): Promise<void> {
  await SecureStore.deleteItemAsync(KEY_SLOT);
}

export class GeminiError extends Error {}

type Part =
  | { text: string }
  | { inline_data: { mime_type: string; data: string } };

async function callGemini(parts: Part[]): Promise<string> {
  const key = await getApiKey();
  if (!key) {
    throw new GeminiError('No Google AI Studio key saved. Add one in Settings.');
  }

  const res = await fetch(`${ENDPOINT}/${MODEL}:generateContent?key=${key}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents: [{ role: 'user', parts }],
      generationConfig: { temperature: 0, responseMimeType: 'application/json' },
    }),
  });

  if (res.status === 400 || res.status === 403) {
    throw new GeminiError('That key was rejected. Check it in Settings.');
  }
  if (res.status === 429) {
    throw new GeminiError('Rate limited by Google. Wait a minute and try again.');
  }
  if (!res.ok) {
    throw new GeminiError(`Google returned ${res.status}. Try again.`);
  }

  const json = await res.json();
  const text: string | undefined = json?.candidates?.[0]?.content?.parts
    ?.map((p: { text?: string }) => p.text ?? '')
    .join('');

  if (!text) throw new GeminiError('Nothing readable came back. Try a clearer file.');
  return text;
}

function parseJson<T>(raw: string): T {
  const cleaned = raw.replace(/^```(?:json)?/m, '').replace(/```$/m, '').trim();
  try {
    return JSON.parse(cleaned) as T;
  } catch {
    throw new GeminiError("Couldn't read the result. Try a clearer file.");
  }
}

// ---------------------------------------------------------------- timetable

const TIMETABLE_PROMPT = `This is a college class timetable. Extract every course and its weekly schedule.

Rules:
- Merge duplicate appearances of the same course into ONE course entry with multiple slots.
- A course's credits equal the number of times it occurs per week (unless credits are explicitly printed).
- Times must be 24-hour HH:MM. If a cell shows a period number instead of a time, infer times from any legend; if impossible, use "09:00" and increment by an hour per period.
- Capture the room or venue printed in the cell if there is one.
- Ignore lunch breaks, free periods, and empty cells.
- If the document contains multiple timetables, extract only the first one.
- Extract ONLY what you can actually read. NEVER invent, guess, or fill in example courses. If the document is not a timetable, is blank, or is too unclear to read confidently, return an empty courses array.

Return JSON: {"courses":[{"name":string,"code":string|null,"credits":number,"slots":[{"day":0-6 with 0=Sunday,"start":"HH:MM","end":"HH:MM","room":string|null}]}]}`;

export type ParsedCourse = {
  name: string;
  code?: string | null;
  credits: number;
  slots: { day: Weekday; start: string; end: string; room?: string | null }[];
};

export async function parseTimetable(
  base64: string,
  mimeType: string
): Promise<ParsedCourse[]> {
  const raw = await callGemini([
    { inline_data: { mime_type: mimeType, data: base64 } },
    { text: TIMETABLE_PROMPT },
  ]);
  const out = parseJson<{ courses?: ParsedCourse[] }>(raw);
  return out.courses ?? [];
}

// ------------------------------------------------------------------- report

const REPORT_PROMPT = `This is an official college attendance report, printed per lecture. Extract one row per lecture.

Rules:
- One object per lecture occurrence. If a subject was taught twice on the same date, emit two rows and keep their times distinct.
- Dates must be YYYY-MM-DD. Convert any DD/MM/YYYY or DD-MON-YYYY dates you find. If the year is missing, infer it from surrounding rows.
- Times must be 24-hour HH:MM. If the report prints a period number or slot label instead of a clock time, return null for time rather than guessing.
- status is "present" for present/P/attended, "absent" for absent/A. Rows marked cancelled, holiday, or not-conducted must be skipped entirely.
- Keep the subject exactly as printed, and its code separately if one is printed.
- asOf is the latest lecture date that appears anywhere in the report.
- Extract ONLY rows you can actually read. NEVER invent rows. If this is not an attendance report, return an empty rows array.

Return JSON: {"asOf":"YYYY-MM-DD","rows":[{"date":"YYYY-MM-DD","subject":string,"code":string|null,"time":"HH:MM"|null,"status":"present"|"absent"}]}`;

export async function parseAttendanceReport(
  base64: string,
  mimeType: string
): Promise<ReportParse> {
  const raw = await callGemini([
    { inline_data: { mime_type: mimeType, data: base64 } },
    { text: REPORT_PROMPT },
  ]);
  const out = parseJson<{ asOf?: string; rows?: ReportRow[] }>(raw);
  const rows = (out.rows ?? []).filter(
    (r) => /^\d{4}-\d{2}-\d{2}$/.test(r.date) && (r.status === 'present' || r.status === 'absent')
  );
  const asOf = out.asOf ?? rows.reduce((max, r) => (r.date > max ? r.date : max), '');
  return { asOf, rows };
}
