import type { Weekday } from '@/types';

export const DAY_NAMES = [
  'Sunday',
  'Monday',
  'Tuesday',
  'Wednesday',
  'Thursday',
  'Friday',
  'Saturday',
] as const;

export const DAY_SHORT = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'] as const;

/** YYYY-MM-DD in local time — never use toISOString(), it shifts across timezones. */
export function toKey(d: Date): string {
  const m = `${d.getMonth() + 1}`.padStart(2, '0');
  const day = `${d.getDate()}`.padStart(2, '0');
  return `${d.getFullYear()}-${m}-${day}`;
}

export function fromKey(key: string): Date {
  const [y, m, d] = key.split('-').map(Number);
  return new Date(y, m - 1, d);
}

export function todayKey(): string {
  return toKey(new Date());
}

export function addDays(key: string, n: number): string {
  const d = fromKey(key);
  d.setDate(d.getDate() + n);
  return toKey(d);
}

export function weekdayOf(key: string): Weekday {
  return fromKey(key).getDay() as Weekday;
}

/** Walks back to the Monday of that date's week. */
export function mondayOf(key: string): string {
  const dow = weekdayOf(key);
  const back = dow === 0 ? 6 : dow - 1;
  return addDays(key, -back);
}

export function isValidKey(key: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(key)) return false;
  const d = fromKey(key);
  return !Number.isNaN(d.getTime()) && toKey(d) === key;
}

export function formatLong(key: string): string {
  const d = fromKey(key);
  return d.toLocaleDateString(undefined, {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
  });
}

export function formatShort(key: string): string {
  const d = fromKey(key);
  return d.toLocaleDateString(undefined, { day: 'numeric', month: 'short' });
}

export function relativeLabel(key: string): string | null {
  const t = todayKey();
  if (key === t) return 'Today';
  if (key === addDays(t, 1)) return 'Tomorrow';
  if (key === addDays(t, -1)) return 'Yesterday';
  return null;
}

/** "14:30" -> "2:30 PM" */
export function prettyTime(hhmm: string): string {
  const [h, m] = hhmm.split(':').map(Number);
  const suffix = h >= 12 ? 'PM' : 'AM';
  const hour = h % 12 === 0 ? 12 : h % 12;
  return `${hour}:${`${m}`.padStart(2, '0')} ${suffix}`;
}

export function timeSort(a: string, b: string): number {
  return a.localeCompare(b);
}

/** Minutes since midnight, for "which lecture is on right now". */
export function minutesOf(hhmm: string): number {
  const [h, m] = hhmm.split(':').map(Number);
  return h * 60 + m;
}
