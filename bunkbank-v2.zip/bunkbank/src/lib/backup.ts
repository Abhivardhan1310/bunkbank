import type { Course, Extra, Mark } from '@/types';
import { weekdayOf } from './date';

/**
 * Plain-text backup. The format is ordinary JSON so it survives being pasted
 * through a notes app or a chat window, and so it can be read by eye when
 * something needs checking.
 */

export const BACKUP_VERSION = 2;

const LEGACY_PALETTE = [
  '#7C5CFF', '#22C9F0', '#2FD8A6', '#F7B733',
  '#FF7A59', '#F45FD0', '#5B8DEF', '#E4C441',
] as const;

export type Snapshot = {
  courses: Course[];
  semesterStart: string;
  holidays: string[];
  extras: Extra[];
  cancellations: string[];
  marks: Record<string, Mark>;
  subjectMap: Record<string, string>;
  target: number;
  teachingWeeks?: number;
  lastReportAsOf?: string;
};

type Envelope = Snapshot & { bunkbank: number; exportedAt: string };

export function exportText(s: Snapshot): string {
  const envelope: Envelope = {
    bunkbank: BACKUP_VERSION,
    exportedAt: new Date().toISOString(),
    ...s,
  };
  return JSON.stringify(envelope);
}

export type ParseResult =
  | { ok: true; data: Snapshot; legacy?: LegacyImport }
  | { ok: false; error: string };

export function parseBackup(text: string): ParseResult {
  const trimmed = text.trim();
  if (!trimmed) return { ok: false, error: 'Nothing pasted yet.' };

  // Tolerate a stray prefix/suffix from a chat app by taking the outermost {}.
  const first = trimmed.indexOf('{');
  const last = trimmed.lastIndexOf('}');
  if (first < 0 || last < first) {
    return { ok: false, error: "That doesn't look like a BunkBank backup." };
  }

  let raw: unknown;
  try {
    raw = JSON.parse(trimmed.slice(first, last + 1));
  } catch {
    return { ok: false, error: 'That text is incomplete — copy the whole backup.' };
  }

  // A backup from the previous version stores sessions rather than a plan.
  if (isLegacyExport(raw)) {
    const legacy = fromLegacy(raw, LEGACY_PALETTE);
    return { ok: true, data: legacy.snapshot, legacy };
  }

  const d = raw as Partial<Envelope>;
  if (!Array.isArray(d.courses) || typeof d.semesterStart !== 'string') {
    return { ok: false, error: "That's valid text but not a BunkBank backup." };
  }

  return {
    ok: true,
    data: {
      courses: d.courses,
      semesterStart: d.semesterStart,
      holidays: d.holidays ?? [],
      extras: d.extras ?? [],
      cancellations: d.cancellations ?? [],
      marks: d.marks ?? {},
      subjectMap: d.subjectMap ?? {},
      target: typeof d.target === 'number' ? d.target : 0.8,
      teachingWeeks: d.teachingWeeks,
      lastReportAsOf: d.lastReportAsOf,
    },
  };
}

export function courseIdOfKey(key: string): string {
  return key.split('|')[1] ?? '';
}

/**
 * How many of a course's lectures were cancelled — explicitly postponed, or
 * falling on a day marked as a holiday. Each one is a lecture the college owes
 * back, so each one can be repaid by an extra class without changing the total.
 */
export function compensableCount(course: Course, s: Snapshot): number {
  let n = 0;
  for (const key of s.cancellations) {
    if (courseIdOfKey(key) === course.id) n++;
  }
  for (const date of s.holidays) {
    const dow = weekdayOf(date);
    for (const slot of course.slots) if (slot.day === dow) n++;
  }
  return n;
}

export function extrasCount(course: Course, s: Snapshot): number {
  return s.extras.filter((e) => e.courseId === course.id).length;
}

/**
 * Lectures that ran on top of the timetable and were NOT making up for anything
 * cancelled. These are genuinely additional classes, so they belong in the total.
 */
export function additionalCount(course: Course, s: Snapshot): number {
  return Math.max(0, extrasCount(course, s) - compensableCount(course, s));
}

export type Repair = {
  changes: string[];
  data: Snapshot;
};

/**
 * Recomputes each course's planned lecture count.
 *
 * The count itself never moves on its own — preponing and postponing only
 * change WHERE lectures sit. What went wrong was the starting number: the
 * importer assumed 15 weeks, so courses ran out of lectures before the term
 * ended. This resets each course to its timetable across the real term, and
 * you can override any of them per course afterwards.
 */
export function repair(s: Snapshot, teachingWeeks: number): Repair {
  const changes: string[] = [];
  const courses = s.courses.map((c) => {
    const perWeek = c.slots.length;
    if (perWeek === 0) return c;
    const planned = perWeek * teachingWeeks;
    if (planned === c.totalLectures) return c;
    changes.push(
      `${c.name}: ${c.totalLectures} → ${planned} (${perWeek}/week × ${teachingWeeks} weeks)`
    );
    return { ...c, totalLectures: planned };
  });
  return { changes, data: { ...s, courses, teachingWeeks } };
}

/** A short human summary of what a backup holds, for the import preview. */
export function describe(s: Snapshot): string[] {
  const marked = Object.keys(s.marks).length;
  const official = Object.values(s.marks).filter((m) => m.source === 'report').length;
  return [
    `${s.courses.length} courses`,
    `${marked} lectures marked${official ? ` (${official} official)` : ''}`,
    `${s.extras.length} extra lectures`,
    `${s.cancellations.length} postponed`,
    `${s.holidays.length} holidays`,
    `semester starts ${s.semesterStart}`,
  ];
}

// --------------------------------------------------------------- legacy v1

/**
 * The previous version of BunkBank stored a materialised list of sessions
 * generated for a fixed number of weeks, and preponing moved a session from the
 * tail to an earlier date. Once the tail ran out there was nothing left to pull
 * forward, and a postponed lecture was simply marked cancelled where it stood
 * and never rescheduled. This reads that export and keeps every record.
 */
type LegacySession = {
  id: string;
  courseId: string;
  slotId: string;
  date: string;
  startTime: string;
  endTime: string;
  room?: string;
  status: 'attended' | 'missed' | 'cancelled' | 'pending' | string;
  isExtra?: boolean;
  movedFrom?: string;
};

type LegacyExport = {
  courses: { id: string; name: string; credits?: number; color?: string }[];
  slots: {
    id: string;
    courseId: string;
    dayOfWeek: number;
    startTime: string;
    endTime: string;
    room?: string;
  }[];
  semester: { startDate: string; weeks: number; holidays?: string[] };
  sessions: LegacySession[];
};

export function isLegacyExport(raw: unknown): boolean {
  const d = raw as Partial<LegacyExport>;
  return (
    Array.isArray(d?.courses) &&
    Array.isArray(d?.slots) &&
    Array.isArray(d?.sessions) &&
    typeof d?.semester === 'object'
  );
}

export type LegacyImport = {
  snapshot: Snapshot;
  /** What was carried across, to show before anything is written. */
  summary: string[];
  /** Lectures that were cancelled and never rescheduled — now owed back. */
  owed: number;
};

export function fromLegacy(raw: unknown, palette: readonly string[]): LegacyImport {
  const d = raw as LegacyExport;
  const at = new Date().toISOString();

  const slotsByCourse = new Map<string, LegacyExport['slots']>();
  for (const s of d.slots) {
    const list = slotsByCourse.get(s.courseId) ?? [];
    list.push(s);
    slotsByCourse.set(s.courseId, list);
  }

  const courses: Course[] = d.courses.map((c, i) => ({
    id: c.id,
    name: c.name,
    color: c.color || palette[i % palette.length],
    slots: (slotsByCourse.get(c.id) ?? []).map((s) => ({
      day: s.dayOfWeek as Course['slots'][number]['day'],
      start: s.startTime,
      end: s.endTime,
      room: s.room,
    })),
    // Every session the old app generated for this course is a lecture the
    // course has. Cancelled ones still count — they are owed, not cancelled
    // away — so this is the course's lecture count, unchanged.
    totalLectures: d.sessions.filter((x) => x.courseId === c.id).length,
  }));

  const marks: Record<string, Mark> = {};
  const cancellations: string[] = [];
  const extras: Extra[] = [];
  let attended = 0;
  let missed = 0;
  let pending = 0;

  // Two lectures of one course can genuinely share a date and time — a day
  // running two preponed slots at once. The scheduler walks dates in order and,
  // within a date, takes timetabled lectures before preponed ones, suffixing any
  // repeat of a key. Matching that order here is what keeps every mark attached
  // to the right lecture instead of one overwriting the other.
  const ordered = [...d.sessions].sort(
    (a, b) =>
      a.date.localeCompare(b.date) ||
      a.startTime.localeCompare(b.startTime) ||
      Number(!!a.isExtra) - Number(!!b.isExtra)
  );

  const usedKeys = new Set<string>();

  for (const s of ordered) {
    let key = `${s.date}|${s.courseId}|${s.startTime}`;
    if (usedKeys.has(key)) {
      let n = 2;
      while (usedKeys.has(`${key}#${n}`)) n++;
      key = `${key}#${n}`;
    }
    usedKeys.add(key);

    if (s.isExtra) {
      extras.push({
        id: `lg_${s.id}`,
        date: s.date,
        courseId: s.courseId,
        start: s.startTime,
        end: s.endTime,
        room: s.room,
      });
    }

    if (s.status === 'attended') {
      marks[key] = { status: 'present', source: 'user', at };
      attended++;
    } else if (s.status === 'missed') {
      marks[key] = { status: 'absent', source: 'user', at };
      missed++;
    } else if (s.status === 'cancelled') {
      cancellations.push(key);
    } else {
      pending++;
    }
  }

  const snapshot: Snapshot = {
    courses,
    semesterStart: d.semester.startDate,
    holidays: d.semester.holidays ?? [],
    extras,
    cancellations,
    marks,
    subjectMap: {},
    target: 0.8,
    teachingWeeks: d.semester.weeks,
  };

  return {
    snapshot,
    owed: cancellations.length,
    summary: [
      `${courses.length} courses with their timetable`,
      `${attended} attended, ${missed} missed — every mark kept`,
      `${cancellations.length} postponed lectures, now owed back`,
      `${extras.length} lectures you pulled forward`,
      `${pending} still unmarked`,
      `semester starts ${d.semester.startDate}`,
    ],
  };
}
