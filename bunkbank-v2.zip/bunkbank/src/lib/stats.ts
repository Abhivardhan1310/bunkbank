import type { Course, CourseStats, Mark } from '@/types';
import { todayKey } from './date';
import type { Schedule } from './schedule';

export const DEFAULT_TARGET = 0.8;

/**
 * Matches v1's numbers exactly. With a 60-lecture course at an 80% target,
 * 18 attended / 6 missed gives "must attend 30" and "6 bunks left":
 *
 *   needed          = ceil(0.8 * 60)      = 48
 *   mustAttend      = 48 - 18             = 30
 *   bunksRemaining  = 60 - 48 - 6         = 6
 *
 * Both are budgets against the *whole semester*, not against lectures held so
 * far, which is why they stay stable when a lecture is postponed to the tail.
 */
export function computeCourseStats(
  course: Course,
  schedule: Schedule,
  marks: Record<string, Mark>,
  target: number = DEFAULT_TARGET
): CourseStats {
  const sessions = schedule.byCourse.get(course.id) ?? [];
  const today = todayKey();

  let attended = 0;
  let missed = 0;
  let unmarkedPast = 0;
  let remaining = 0;

  for (const s of sessions) {
    const mark = marks[s.key];
    if (mark) {
      if (mark.status === 'present') attended++;
      else missed++;
    } else if (s.date < today) {
      unmarkedPast++;
    } else {
      remaining++;
    }
  }

  const total = course.totalLectures;
  const held = attended + missed;
  const needed = Math.ceil(target * total);

  return {
    courseId: course.id,
    total,
    attended,
    missed,
    held,
    unmarkedPast,
    remaining,
    currentPct: held > 0 ? attended / held : 0,
    projectedPct: total > 0 ? (total - missed) / total : 0,
    mustAttend: Math.max(0, needed - attended),
    bunksRemaining: Math.max(0, total - needed - missed),
    lastDate: schedule.lastDateByCourse.get(course.id),
  };
}

export function computeAllStats(
  courses: Course[],
  schedule: Schedule,
  marks: Record<string, Mark>,
  target: number = DEFAULT_TARGET
): Map<string, CourseStats> {
  const out = new Map<string, CourseStats>();
  for (const c of courses) out.set(c.id, computeCourseStats(c, schedule, marks, target));
  return out;
}

/** The single number in the header ring: attended over everything actually held. */
export function overallPct(stats: Map<string, CourseStats>): number {
  let attended = 0;
  let held = 0;
  for (const s of stats.values()) {
    attended += s.attended;
    held += s.held;
  }
  return held > 0 ? attended / held : 0;
}

export function pctLabel(pct: number): string {
  return `${Math.round(pct * 100)}%`;
}

/** Colour ramp for a percentage against the target. */
export function pctTone(
  pct: number,
  target: number = DEFAULT_TARGET
): 'good' | 'warn' | 'bad' {
  if (pct >= target) return 'good';
  if (pct >= target - 0.1) return 'warn';
  return 'bad';
}
