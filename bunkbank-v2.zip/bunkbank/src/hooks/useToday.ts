import { useEffect, useState } from 'react';
import { AppState, type AppStateStatus } from 'react-native';
import { todayKey } from '@/lib/date';

/**
 * Today's date, kept honest.
 *
 * Reading todayKey() during render is only correct until midnight. Phones keep
 * apps alive for days, so an app opened on the 1st after being backgrounded on
 * the 30th would keep showing the 30th — including "all marked" for a day that
 * had already finished. This re-checks whenever the app comes back to the
 * foreground, and schedules a tick for the next midnight while it stays open.
 */
export function useToday(): string {
  const [day, setDay] = useState(todayKey);

  useEffect(() => {
    const sync = () => setDay((prev) => (prev === todayKey() ? prev : todayKey()));

    const sub = AppState.addEventListener('change', (next: AppStateStatus) => {
      if (next === 'active') sync();
    });

    // Fire shortly after the next local midnight, then every day it stays open.
    let daily: ReturnType<typeof setInterval> | undefined;
    const now = new Date();
    const midnight = new Date(now);
    midnight.setHours(24, 0, 2, 0);
    const first = setTimeout(() => {
      sync();
      daily = setInterval(sync, 24 * 60 * 60 * 1000);
    }, midnight.getTime() - now.getTime());

    // A cheap safety net for a device whose clock jumps (timezone, manual change).
    const poll = setInterval(sync, 60 * 1000);

    return () => {
      sub.remove();
      clearTimeout(first);
      clearInterval(poll);
      if (daily) clearInterval(daily);
    };
  }, []);

  return day;
}
