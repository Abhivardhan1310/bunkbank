export type Weekday = 0 | 1 | 2 | 3 | 4 | 5 | 6; // 0 = Sunday

export type Slot = {
  day: Weekday;
  start: string; // "HH:MM" 24h
  end: string;
  room?: string;
};

export type Course = {
  id: string;
  name: string;
  code?: string; // SAP subject code, used for report matching
  color: string;
  slots: Slot[];
  /**
   * Planned number of lectures for the whole semester. This is the budget the
   * scheduler spends. Every mechanism in the app (extra lectures, postponement,
   * holidays, cloned days) works by changing WHEN the budget is spent, never how
   * much of it there is — so the semester total stays fixed by construction.
   */
  totalLectures: number;
};

/** A lecture added onto a date that the weekly timetable does not cover. */
export type Extra = {
  id: string;
  date: string; // YYYY-MM-DD
  courseId: string;
  start: string;
  end: string;
  room?: string;
  /** Set when a whole weekday was cloned onto this date, so it can be undone as a unit. */
  cloneId?: string;
  /** Cloned from this weekday, for display ("Monday schedule"). */
  sourceDay?: Weekday;
  /** True when the row came from an official report rather than the user. */
  fromReport?: boolean;
};

export type MarkStatus = 'present' | 'absent';

export type Mark = {
  status: MarkStatus;
  source: 'user' | 'report';
  at: string; // ISO timestamp
};

export type SessionKind = 'regular' | 'extra';

/** One concrete lecture on one concrete date, produced by the scheduler. */
export type Session = {
  key: string; // `${date}|${courseId}|${start}`
  date: string;
  courseId: string;
  start: string;
  end: string;
  room?: string;
  kind: SessionKind;
  /** 1-based: this is lecture n of course.totalLectures. */
  index: number;
  cloneId?: string;
  sourceDay?: Weekday;
};

/** A slot that would have run but was cancelled — shown greyed out, costs no budget. */
export type CancelledSession = {
  key: string;
  date: string;
  courseId: string;
  start: string;
  end: string;
  room?: string;
  reason: 'postponed' | 'holiday';
};

export type CourseStats = {
  courseId: string;
  total: number; // = course.totalLectures
  attended: number;
  missed: number;
  held: number; // attended + missed
  unmarkedPast: number;
  remaining: number; // sessions still ahead of today
  currentPct: number; // attended / held
  projectedPct: number; // if every remaining lecture is attended
  /** Lectures still needed to finish the semester at or above target. */
  mustAttend: number;
  /** Lectures that can still be skipped and stay at or above target. */
  bunksRemaining: number;
  lastDate?: string;
};

/** One row lifted out of an official attendance report. */
export type ReportRow = {
  date: string; // YYYY-MM-DD
  subject: string;
  code?: string;
  time?: string | null; // "HH:MM" if the report prints it
  status: MarkStatus;
};

export type ReportParse = {
  asOf: string; // latest date the report covers
  rows: ReportRow[];
};

export type ReconcileResult = {
  asOf: string;
  overwritten: number; // existing sessions whose mark the report changed
  confirmed: number; // sessions where report agreed with what was already there
  inserted: number; // lectures the report knew about that we had not scheduled
  unmatchedSubjects: string[]; // subject labels with no course mapping yet
  keptOwn: number; // past sessions the report never mentioned, left untouched
};
