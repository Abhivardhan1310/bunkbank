import React, { useCallback } from 'react';
import { Dimensions, StyleSheet, Text, View } from 'react-native';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import Animated, {
  Extrapolation,
  interpolate,
  runOnJS,
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import { Ionicons } from '@expo/vector-icons';
import { C, S } from '@/theme';
import { prettyTime } from '@/lib/date';
import type { Course, MarkStatus, Session } from '@/types';

const { width: SCREEN_W } = Dimensions.get('window');
const THRESHOLD = SCREEN_W * 0.28;
const FLING_OUT = SCREEN_W * 1.4;

export type SwipeCardProps = {
  session: Session;
  course: Course;
  subtitle: string;
  index: number; // 0 = front of deck
  onDecide: (status: MarkStatus) => void;
};

export function SwipeCard({ session, course, subtitle, index, onDecide }: SwipeCardProps) {
  const tx = useSharedValue(0);
  const ty = useSharedValue(0);
  const gone = useSharedValue(false);

  const decide = useCallback(
    (status: MarkStatus) => {
      onDecide(status);
    },
    [onDecide]
  );

  const pan = Gesture.Pan()
    .enabled(index === 0)
    .onUpdate((e) => {
      tx.value = e.translationX;
      ty.value = e.translationY * 0.35;
    })
    .onEnd((e) => {
      const flung = Math.abs(e.velocityX) > 900;
      const past = Math.abs(tx.value) > THRESHOLD;
      if (!past && !flung) {
        tx.value = withSpring(0, { damping: 18 });
        ty.value = withSpring(0, { damping: 18 });
        return;
      }
      const dir = tx.value > 0 ? 1 : -1;
      gone.value = true;
      tx.value = withTiming(dir * FLING_OUT, { duration: 200 }, () => {
        runOnJS(decide)(dir > 0 ? 'present' : 'absent');
      });
    });

  const cardStyle = useAnimatedStyle(() => {
    const rot = interpolate(
      tx.value,
      [-SCREEN_W, 0, SCREEN_W],
      [-11, 0, 11],
      Extrapolation.CLAMP
    );
    const rest = index === 0 ? 0 : Math.min(index, 2);
    return {
      transform: [
        { translateX: tx.value },
        { translateY: ty.value + rest * 12 },
        { rotate: `${rot}deg` },
        { scale: 1 - rest * 0.04 },
      ],
      zIndex: 100 - index,
    };
  });

  const attendedStamp = useAnimatedStyle(() => ({
    opacity: interpolate(tx.value, [0, THRESHOLD], [0, 1], Extrapolation.CLAMP),
  }));

  const missedStamp = useAnimatedStyle(() => ({
    opacity: interpolate(tx.value, [-THRESHOLD, 0], [1, 0], Extrapolation.CLAMP),
  }));

  return (
    <GestureDetector gesture={pan}>
      <Animated.View style={[styles.card, cardStyle]}>
        <View style={[styles.topRule, { backgroundColor: course.color }]} />

        <Animated.View style={[styles.stamp, styles.stampRight, attendedStamp]}>
          <Text style={[styles.stampText, { color: C.green }]}>ATTENDED</Text>
        </Animated.View>
        <Animated.View style={[styles.stamp, styles.stampLeft, missedStamp]}>
          <Text style={[styles.stampText, { color: C.red }]}>MISSED</Text>
        </Animated.View>

        <View style={styles.body}>
          <View style={[styles.dot, { backgroundColor: course.color }]} />
          <Text style={styles.title} numberOfLines={4}>
            {course.name}
          </Text>

          <View style={{ flex: 1 }} />

          <View style={styles.metaRow}>
            <Ionicons name="time-outline" size={18} color={C.dim} />
            <Text style={styles.meta}>
              {prettyTime(session.start)} – {prettyTime(session.end)}
            </Text>
            {session.room ? (
              <>
                <Ionicons name="location-outline" size={18} color={C.dim} style={{ marginLeft: 14 }} />
                <Text style={styles.meta}>{session.room}</Text>
              </>
            ) : null}
          </View>

          <View style={styles.divider} />

          <View style={styles.metaRow}>
            <Ionicons name="shield-checkmark-outline" size={18} color={C.faint} />
            <Text style={styles.sub}>{subtitle}</Text>
          </View>
        </View>
      </Animated.View>
    </GestureDetector>
  );
}

const styles = StyleSheet.create({
  card: {
    position: 'absolute',
    left: S.gutter,
    right: S.gutter,
    top: 0,
    bottom: 0,
    backgroundColor: C.surface,
    borderRadius: 26,
    overflow: 'hidden',
  },
  topRule: { height: 6, width: '100%' },
  body: { flex: 1, padding: 26 },
  dot: { width: 14, height: 14, borderRadius: 7, marginBottom: 22 },
  title: { fontSize: 34, lineHeight: 42, fontWeight: '800', color: C.text, letterSpacing: -0.8 },
  metaRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  meta: { fontSize: 17, color: C.dim, fontWeight: '600' },
  sub: { fontSize: 16, color: C.faint, fontWeight: '600' },
  divider: { height: 1, backgroundColor: C.border, marginVertical: 18 },
  stamp: {
    position: 'absolute',
    top: 46,
    borderWidth: 4,
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 6,
    zIndex: 5,
  },
  stampRight: { right: 20, transform: [{ rotate: '14deg' }], borderColor: C.green },
  stampLeft: { left: 20, transform: [{ rotate: '-14deg' }], borderColor: C.red },
  stampText: { fontSize: 30, fontWeight: '900', letterSpacing: 1 },
});
