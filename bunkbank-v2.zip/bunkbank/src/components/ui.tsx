import React from 'react';
import {
  ActivityIndicator,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
  type StyleProp,
  type ViewStyle,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Svg, { Circle } from 'react-native-svg';
import { C, S, type as T } from '@/theme';

export function Screen({
  children,
  scroll = true,
  style,
}: {
  children: React.ReactNode;
  scroll?: boolean;
  style?: StyleProp<ViewStyle>;
}) {
  const insets = useSafeAreaInsets();
  const pad = { paddingTop: insets.top + 12, paddingBottom: 28 };
  if (!scroll) {
    return <View style={[styles.screen, pad, style]}>{children}</View>;
  }
  return (
    <ScrollView
      style={styles.screen}
      contentContainerStyle={[pad, { paddingBottom: 48 }, style]}
      showsVerticalScrollIndicator={false}
    >
      {children}
    </ScrollView>
  );
}

export function Title({ children, right }: { children: React.ReactNode; right?: React.ReactNode }) {
  return (
    <View style={styles.titleRow}>
      <Text style={T.screenTitle}>{children}</Text>
      {right}
    </View>
  );
}

export function Eyebrow({ children }: { children: React.ReactNode }) {
  return <Text style={[T.eyebrow, { paddingHorizontal: S.gutter, marginBottom: 10 }]}>{children}</Text>;
}

export function Card({
  children,
  onPress,
  style,
  accent,
}: {
  children: React.ReactNode;
  onPress?: () => void;
  style?: StyleProp<ViewStyle>;
  accent?: string;
}) {
  const body = (
    <View style={[styles.card, style]}>
      {accent ? <View style={[styles.accentBar, { backgroundColor: accent }]} /> : null}
      <View style={{ flex: 1 }}>{children}</View>
    </View>
  );
  if (!onPress) return body;
  return (
    <Pressable onPress={onPress} style={({ pressed }) => ({ opacity: pressed ? 0.7 : 1 })}>
      {body}
    </Pressable>
  );
}

export function Button({
  label,
  onPress,
  tone = 'primary',
  disabled,
  loading,
  style,
}: {
  label: string;
  onPress: () => void;
  tone?: 'primary' | 'ghost' | 'danger' | 'good';
  disabled?: boolean;
  loading?: boolean;
  style?: StyleProp<ViewStyle>;
}) {
  const bg =
    tone === 'primary'
      ? C.blue
      : tone === 'good'
        ? C.green
        : tone === 'danger'
          ? C.redDim
          : C.surfaceAlt;
  const fg = tone === 'primary' || tone === 'good' ? C.bg : tone === 'danger' ? C.red : C.text;
  const off = disabled || loading;
  return (
    <Pressable
      onPress={off ? undefined : onPress}
      style={({ pressed }) => [
        styles.button,
        { backgroundColor: bg, opacity: off ? 0.45 : pressed ? 0.8 : 1 },
        style,
      ]}
      accessibilityRole="button"
      accessibilityState={{ disabled: !!off }}
    >
      {loading ? (
        <ActivityIndicator color={fg} />
      ) : (
        <Text style={[styles.buttonLabel, { color: fg }]}>{label}</Text>
      )}
    </Pressable>
  );
}

export function Pill({
  label,
  tone = 'neutral',
}: {
  label: string;
  tone?: 'neutral' | 'good' | 'warn' | 'bad';
}) {
  const map = {
    neutral: { bg: C.surfaceAlt, fg: C.dim },
    good: { bg: C.greenDim, fg: C.green },
    warn: { bg: C.amberDim, fg: C.amber },
    bad: { bg: C.redDim, fg: C.red },
  } as const;
  const { bg, fg } = map[tone];
  return (
    <View style={[styles.pill, { backgroundColor: bg }]}>
      <Text style={{ color: fg, fontSize: 14, fontWeight: '700' }}>{label}</Text>
    </View>
  );
}

export function Dot({ color, size = 12 }: { color: string; size?: number }) {
  return (
    <View
      style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: color }}
    />
  );
}

export function Ring({
  pct,
  size = 74,
  stroke = 7,
  color = C.amber,
  label,
}: {
  pct: number;
  size?: number;
  stroke?: number;
  color?: string;
  label?: string;
}) {
  const r = (size - stroke) / 2;
  const circumference = 2 * Math.PI * r;
  const clamped = Math.max(0, Math.min(1, pct));
  return (
    <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      <Svg width={size} height={size} style={StyleSheet.absoluteFill}>
        <Circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke={C.surfaceAlt}
          strokeWidth={stroke}
          fill="none"
        />
        <Circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke={color}
          strokeWidth={stroke}
          strokeLinecap="round"
          fill="none"
          strokeDasharray={`${circumference} ${circumference}`}
          strokeDashoffset={circumference * (1 - clamped)}
          transform={`rotate(-90 ${size / 2} ${size / 2})`}
        />
      </Svg>
      <Text style={{ color: C.text, fontWeight: '800', fontSize: size / 4 }}>
        {label ?? `${Math.round(clamped * 100)}%`}
      </Text>
    </View>
  );
}

export function Empty({
  title,
  body,
  action,
}: {
  title: string;
  body: string;
  action?: React.ReactNode;
}) {
  return (
    <View style={styles.empty}>
      <Text style={styles.emptyTitle}>{title}</Text>
      <Text style={styles.emptyBody}>{body}</Text>
      {action ? <View style={{ marginTop: 20, alignSelf: 'stretch' }}>{action}</View> : null}
    </View>
  );
}

export function Row({
  label,
  value,
  onPress,
  destructive,
}: {
  label: string;
  value?: string;
  onPress?: () => void;
  destructive?: boolean;
}) {
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [styles.row, { opacity: pressed && onPress ? 0.6 : 1 }]}
    >
      <Text style={[T.rowTitle, destructive && { color: C.red }]}>{label}</Text>
      {value ? <Text style={[T.meta, { flexShrink: 1, textAlign: 'right' }]}>{value}</Text> : null}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: C.bg },
  titleRow: {
    paddingHorizontal: S.gutter,
    paddingBottom: 18,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 12,
  },
  card: {
    backgroundColor: C.surface,
    borderRadius: S.radius,
    marginHorizontal: S.gutter,
    marginBottom: 14,
    padding: 18,
    flexDirection: 'row',
    gap: 14,
    overflow: 'hidden',
  },
  accentBar: { width: 4, borderRadius: 2, alignSelf: 'stretch' },
  button: {
    borderRadius: 14,
    paddingVertical: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonLabel: { fontSize: 17, fontWeight: '700' },
  pill: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: 999 },
  empty: { paddingHorizontal: S.gutter, paddingTop: 60, alignItems: 'center' },
  emptyTitle: { ...T.rowTitle, fontSize: 22, marginBottom: 8, textAlign: 'center' },
  emptyBody: { ...T.meta, textAlign: 'center', lineHeight: 22 },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 17,
    paddingHorizontal: 18,
    gap: 16,
  },
});

export { styles as uiStyles };
