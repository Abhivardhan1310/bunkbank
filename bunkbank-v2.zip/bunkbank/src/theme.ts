export const C = {
  bg: '#0B0F14',
  surface: '#161D26',
  surfaceAlt: '#1E2731',
  border: '#242F3B',
  text: '#FFFFFF',
  dim: '#9AA7B6',
  faint: '#5C6875',
  green: '#2FD8A6',
  greenDim: '#123A31',
  red: '#FF5A6B',
  redDim: '#3A1620',
  amber: '#F7B733',
  amberDim: '#3A2E11',
  blue: '#22C9F0',
} as const;

/** Course accent colours, assigned in order as courses are created. */
export const COURSE_COLORS = [
  '#7C5CFF',
  '#22C9F0',
  '#2FD8A6',
  '#F7B733',
  '#FF7A59',
  '#F45FD0',
  '#5B8DEF',
  '#E4C441',
  '#FF5A6B',
  '#12B886',
] as const;

export function nextColor(usedCount: number): string {
  return COURSE_COLORS[usedCount % COURSE_COLORS.length];
}

export const S = {
  gutter: 20,
  radius: 18,
  radiusSm: 12,
} as const;

export const type = {
  screenTitle: { fontSize: 40, fontWeight: '800' as const, color: C.text, letterSpacing: -1 },
  eyebrow: {
    fontSize: 13,
    fontWeight: '700' as const,
    color: C.dim,
    letterSpacing: 1.6,
    textTransform: 'uppercase' as const,
  },
  cardTitle: { fontSize: 30, fontWeight: '800' as const, color: C.text, letterSpacing: -0.6 },
  rowTitle: { fontSize: 18, fontWeight: '700' as const, color: C.text },
  meta: { fontSize: 15, color: C.dim },
  small: { fontSize: 13, color: C.faint },
};
