import React, { useMemo, useState } from 'react';
import { Alert, Pressable, StyleSheet, Text, View } from 'react-native';
import * as DocumentPicker from 'expo-document-picker';
import * as FileSystem from 'expo-file-system/legacy';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useStore } from '@/store';
import { Button, Card, Eyebrow, Screen } from '@/components/ui';
import { C, S } from '@/theme';
import { formatLong } from '@/lib/date';
import { GeminiError, parseAttendanceReport } from '@/lib/gemini';
import {
  reconcile,
  summarise,
  unresolvedSubjects,
  type ReconcilePlan,
} from '@/lib/report';
import type { ReportParse } from '@/types';

type Stage = 'idle' | 'reading' | 'review' | 'error';

export default function ImportReport() {
  const router = useRouter();
  const [stage, setStage] = useState<Stage>('idle');
  const [error, setError] = useState('');
  const [parse, setParse] = useState<ReportParse | null>(null);

  const courses = useStore((s) => s.courses);
  const schedule = useStore((s) => s.schedule);
  const marks = useStore((s) => s.marks);
  const subjectMap = useStore((s) => s.subjectMap);
  const applyReportMarks = useStore((s) => s.applyReportMarks);

  const plan: ReconcilePlan | null = useMemo(() => {
    if (!parse) return null;
    return reconcile(parse, courses, schedule, marks, subjectMap);
  }, [parse, courses, schedule, marks, subjectMap]);

  const unresolved = useMemo(
    () => (parse ? unresolvedSubjects(parse, courses, subjectMap) : []),
    [parse, courses, subjectMap]
  );

  const pick = async () => {
    const res = await DocumentPicker.getDocumentAsync({
      type: ['application/pdf', 'image/*'],
      copyToCacheDirectory: true,
    });
    if (res.canceled || !res.assets?.[0]) return;

    const file = res.assets[0];
    if (file.size && file.size > 15 * 1024 * 1024) {
      setError('Please use a file under 15 MB.');
      setStage('error');
      return;
    }

    setStage('reading');
    setError('');
    try {
      const base64 = await FileSystem.readAsStringAsync(file.uri, {
        encoding: FileSystem.EncodingType.Base64,
      });
      const result = await parseAttendanceReport(base64, file.mimeType ?? 'application/pdf');
      if (result.rows.length === 0) {
        setError("Couldn't find any lecture rows in that file. Use the detailed report, not the summary.");
        setStage('error');
        return;
      }
      setParse(result);
      setStage('review');
    } catch (e) {
      setError(e instanceof GeminiError ? e.message : 'Something went wrong reading that file.');
      setStage('error');
    }
  };

  const apply = () => {
    if (!plan || !parse) return;
    applyReportMarks(plan.marks, plan.newExtras, plan.totalAdjustments, parse.asOf);
    Alert.alert('Report applied', summarise(plan.result), [
      { text: 'Done', onPress: () => router.back() },
    ]);
  };

  return (
    <Screen>
      <View style={styles.head}>
        <Pressable onPress={() => router.back()} hitSlop={12}>
          <Ionicons name="close" size={30} color={C.text} />
        </Pressable>
        <Text style={styles.title}>Official report</Text>
      </View>

      {stage === 'idle' || stage === 'error' ? (
        <>
          <Card>
            <Text style={styles.body}>
              Attach the detailed per-lecture attendance report from your college portal. Rows in
              the report replace what you swiped. Lectures the report doesn&apos;t mention keep your
              own marking.
            </Text>
          </Card>
          {stage === 'error' ? (
            <Card>
              <Text style={styles.error}>{error}</Text>
            </Card>
          ) : null}
          <View style={{ paddingHorizontal: S.gutter }}>
            <Button label="Choose PDF" onPress={pick} />
          </View>
        </>
      ) : null}

      {stage === 'reading' ? (
        <Card>
          <Text style={styles.body}>Reading the report. This usually takes a few seconds.</Text>
        </Card>
      ) : null}

      {stage === 'review' && plan && parse ? (
        <>
          <Eyebrow>What will change</Eyebrow>
          <Card>
            <Line
              icon="calendar-outline"
              label="Report covers up to"
              value={formatLong(parse.asOf)}
            />
            <Line icon="document-text-outline" label="Lecture rows read" value={`${parse.rows.length}`} />
            <Line
              icon="swap-horizontal-outline"
              label="Marks changed"
              value={`${plan.result.overwritten}`}
              tone={plan.result.overwritten ? C.amber : undefined}
            />
            <Line
              icon="checkmark-circle-outline"
              label="Already matched"
              value={`${plan.result.confirmed}`}
            />
            <Line
              icon="add-circle-outline"
              label="Lectures added to totals"
              value={`${plan.result.inserted}`}
              tone={plan.result.inserted ? C.blue : undefined}
            />
            <Line
              icon="hand-left-outline"
              label="Your marks kept"
              value={`${plan.result.keptOwn}`}
            />
          </Card>

          {unresolved.length > 0 ? (
            <Card>
              <Text style={styles.warnTitle}>
                {unresolved.length} subject{unresolved.length === 1 ? '' : 's'} not matched
              </Text>
              <Text style={styles.body}>
                {unresolved.join(', ')} — these rows will be skipped until you match them to a
                course.
              </Text>
              <Button
                label="Match subjects"
                tone="ghost"
                style={{ marginTop: 14 }}
                onPress={() =>
                  router.push({
                    pathname: '/map-subjects',
                    params: { subjects: unresolved.join('||') },
                  })
                }
              />
            </Card>
          ) : null}

          {plan.result.inserted > 0 ? (
            <Card>
              <Text style={styles.body}>
                The report lists {plan.result.inserted} lecture
                {plan.result.inserted === 1 ? '' : 's'} that weren&apos;t on your schedule. Those get
                added and the course totals go up to match — the report is the authority on how many
                lectures actually ran.
              </Text>
            </Card>
          ) : null}

          <View style={{ paddingHorizontal: S.gutter, gap: 10 }}>
            <Button label="Apply report" onPress={apply} />
            <Button label="Choose a different file" tone="ghost" onPress={pick} />
          </View>
        </>
      ) : null}
    </Screen>
  );
}

function Line({
  icon,
  label,
  value,
  tone,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
  value: string;
  tone?: string;
}) {
  return (
    <View style={styles.line}>
      <Ionicons name={icon} size={18} color={tone ?? C.faint} />
      <Text style={styles.lineLabel}>{label}</Text>
      <Text style={[styles.lineValue, tone ? { color: tone } : null]}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  head: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    paddingHorizontal: S.gutter,
    marginBottom: 22,
  },
  title: { fontSize: 28, fontWeight: '800', color: C.text, letterSpacing: -0.6 },
  body: { fontSize: 15, color: C.dim, lineHeight: 23 },
  error: { fontSize: 15, color: C.red, lineHeight: 22 },
  warnTitle: { fontSize: 17, fontWeight: '700', color: C.amber, marginBottom: 8 },
  line: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 9 },
  lineLabel: { flex: 1, fontSize: 15, color: C.dim },
  lineValue: { fontSize: 16, fontWeight: '700', color: C.text },
});
