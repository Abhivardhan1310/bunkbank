import React, { useMemo, useState } from 'react';
import { Alert, Pressable, Share, StyleSheet, Text, TextInput, View } from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useStore, snapshotOf } from '@/store';
import { Button, Card, Eyebrow, Screen } from '@/components/ui';
import { C, S } from '@/theme';
import { describe, exportText, parseBackup, type Snapshot } from '@/lib/backup';

export default function Backup() {
  const router = useRouter();
  const state = useStore();
  const importSnapshot = useStore((s) => s.importSnapshot);

  const [mode, setMode] = useState<'export' | 'import'>('export');
  const [pasted, setPasted] = useState('');

  const text = useMemo(() => exportText(snapshotOf(state)), [state]);

  const parsed = useMemo(() => (pasted.trim() ? parseBackup(pasted) : null), [pasted]);
  const incoming: Snapshot | null = parsed?.ok ? parsed.data : null;
  const legacy = parsed?.ok ? parsed.legacy : undefined;

  const share = async () => {
    try {
      await Share.share({ message: text });
    } catch {
      Alert.alert('Could not share', 'Select the text below and copy it instead.');
    }
  };

  const apply = () => {
    if (!incoming) return;
    Alert.alert(
      'Replace everything?',
      'Your current courses, schedule and attendance will be replaced by this backup.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Import',
          style: 'destructive',
          onPress: () => {
            importSnapshot(incoming);
            Alert.alert(
              'Restored',
              legacy
                ? `Every mark carried across. ${legacy.owed} postponed lectures were added back at the end of the semester.`
                : 'Everything is back exactly as it was.',
              [
                { text: 'Done', onPress: () => router.replace('/(tabs)') },
              ]
            );
          },
        },
      ]
    );
  };

  return (
    <Screen>
      <View style={styles.head}>
        <Pressable onPress={() => router.back()} hitSlop={12}>
          <Ionicons name="close" size={30} color={C.text} />
        </Pressable>
        <Text style={styles.title}>Backup</Text>
      </View>

      <View style={styles.tabs}>
        <Tab label="Export" on={mode === 'export'} onPress={() => setMode('export')} />
        <Tab label="Import" on={mode === 'import'} onPress={() => setMode('import')} />
      </View>

      {mode === 'export' ? (
        <>
          <Card>
            <Text style={styles.body}>
              This is your whole semester as text — courses, timetable, every lecture you marked,
              holidays and postponements. Send it to yourself, or copy it straight out of the box
              below.
            </Text>
          </Card>

          <Eyebrow>What's in it</Eyebrow>
          <Card>
            {describe(snapshotOf(state)).map((line) => (
              <Text key={line} style={styles.line}>
                • {line}
              </Text>
            ))}
            <Text style={styles.hint}>{text.length.toLocaleString()} characters</Text>
          </Card>

          <View style={{ paddingHorizontal: S.gutter, marginBottom: 14 }}>
            <Button label="Send backup" onPress={share} />
          </View>

          <Eyebrow>Or copy it by hand</Eyebrow>
          <Card>
            <TextInput
              value={text}
              multiline
              editable={false}
              selectTextOnFocus
              style={styles.blob}
            />
            <Text style={styles.hint}>
              Long-press inside the box, choose Select all, then Copy.
            </Text>
          </Card>
        </>
      ) : (
        <>
          <Card>
            <Text style={styles.body}>
              Paste a backup here. Works with an export from the previous version too — every
              lecture you have marked is carried across, and postponed lectures get put back at the
              end of the semester where they belong.
            </Text>
          </Card>

          <Card>
            <TextInput
              value={pasted}
              onChangeText={setPasted}
              multiline
              placeholder="Paste your backup text here"
              placeholderTextColor={C.faint}
              style={styles.blob}
              autoCapitalize="none"
              autoCorrect={false}
            />
          </Card>

          {parsed && !parsed.ok ? (
            <Card>
              <Text style={styles.error}>{parsed.error}</Text>
            </Card>
          ) : null}

          {incoming ? (
            <>
              <Eyebrow>{legacy ? 'From your previous version' : 'This backup holds'}</Eyebrow>
              <Card>
                {(legacy ? legacy.summary : describe(incoming)).map((line) => (
                  <Text key={line} style={styles.line}>
                    • {line}
                  </Text>
                ))}
              </Card>
              {legacy && legacy.owed > 0 ? (
                <Card accent={C.green}>
                  <Text style={styles.body}>
                    The old version marked {legacy.owed} lectures cancelled and never gave them
                    back. They are added to the end of the semester on import, so your courses stop
                    running out early.
                  </Text>
                </Card>
              ) : null}
            </>
          ) : null}

          <View style={{ paddingHorizontal: S.gutter, gap: 10 }}>
            <Button label="Import this backup" onPress={apply} disabled={!incoming} />
            <Button label="Clear" tone="ghost" onPress={() => setPasted('')} />
          </View>
        </>
      )}
    </Screen>
  );
}

function Tab({ label, on, onPress }: { label: string; on: boolean; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} style={[styles.tab, on && styles.tabOn]}>
      <Text style={[styles.tabText, on && styles.tabTextOn]}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  head: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    paddingHorizontal: S.gutter,
    marginBottom: 18,
  },
  title: { fontSize: 28, fontWeight: '800', color: C.text, letterSpacing: -0.6 },
  tabs: {
    flexDirection: 'row',
    gap: 8,
    marginHorizontal: S.gutter,
    marginBottom: 18,
    backgroundColor: C.surface,
    borderRadius: 14,
    padding: 5,
  },
  tab: { flex: 1, paddingVertical: 11, borderRadius: 10, alignItems: 'center' },
  tabOn: { backgroundColor: C.surfaceAlt },
  tabText: { color: C.dim, fontWeight: '700', fontSize: 16 },
  tabTextOn: { color: C.text },
  body: { fontSize: 15, color: C.dim, lineHeight: 23 },
  line: { fontSize: 15, color: C.text, paddingVertical: 3 },
  hint: { fontSize: 13, color: C.faint, marginTop: 10, lineHeight: 19 },
  error: { fontSize: 15, color: C.red, lineHeight: 22 },
  blob: {
    backgroundColor: C.surfaceAlt,
    borderRadius: 12,
    padding: 14,
    color: C.text,
    fontSize: 12,
    minHeight: 150,
    maxHeight: 260,
    textAlignVertical: 'top',
    fontFamily: 'monospace',
  },
});
