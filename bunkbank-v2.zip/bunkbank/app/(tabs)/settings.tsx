import React, { useState } from 'react';
import { Alert, StyleSheet, Text, TextInput, View } from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useStore } from '@/store';
import { Button, Card, Dot, Eyebrow, Row, Screen, Title } from '@/components/ui';
import { C, S } from '@/theme';
import { formatLong, isValidKey } from '@/lib/date';
import { getApiKey, setApiKey } from '@/lib/gemini';

export default function Settings() {
  const router = useRouter();
  const courses = useStore((s) => s.courses);
  const semesterStart = useStore((s) => s.semesterStart);
  const target = useStore((s) => s.target);
  const schedule = useStore((s) => s.schedule);
  const lastReportAsOf = useStore((s) => s.lastReportAsOf);
  const setSemesterStart = useStore((s) => s.setSemesterStart);
  const setTarget = useStore((s) => s.setTarget);
  const reset = useStore((s) => s.reset);

  const teachingWeeks = useStore((s) => s.teachingWeeks);
  const setTeachingWeeks = useStore((s) => s.setTeachingWeeks);
  const lastRepairChanges = useStore((s) => s.lastRepairChanges);
  const clearRepairNotice = useStore((s) => s.clearRepairNotice);
  const runRepair = useStore((s) => s.runRepair);
  const [weeksDraft, setWeeksDraft] = useState(`${teachingWeeks}`);
  const [keyDraft, setKeyDraft] = useState('');
  const [keySaved, setKeySaved] = useState<boolean | null>(null);
  const [startDraft, setStartDraft] = useState(semesterStart);

  React.useEffect(() => {
    getApiKey().then((k) => setKeySaved(!!k));
  }, []);

  const saveKey = async () => {
    if (!keyDraft.trim()) return;
    await setApiKey(keyDraft);
    setKeyDraft('');
    setKeySaved(true);
    Alert.alert('Key saved', 'Timetable and report imports will use it.');
  };

  const saveStart = () => {
    if (!isValidKey(startDraft)) {
      Alert.alert('Check the date', 'Semester start must be YYYY-MM-DD.');
      return;
    }
    setSemesterStart(startDraft);
  };

  const confirmReset = () => {
    Alert.alert(
      'Reset everything?',
      'All courses, schedule, and attendance records will be permanently deleted.',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Delete', style: 'destructive', onPress: () => reset() },
      ]
    );
  };

  return (
    <Screen>
      <Title>Settings</Title>

      {lastRepairChanges && lastRepairChanges.length > 0 ? (
        <Card accent={C.green}>
          <Text style={styles.fixedTitle}>Lecture totals repaired</Text>
          <Text style={styles.body}>Lecture counts were recalculated from your timetable:</Text>
          {lastRepairChanges.map((line) => (
            <Text key={line} style={styles.line}>
              • {line}
            </Text>
          ))}
          <Button label="Got it" tone="ghost" style={{ marginTop: 14 }} onPress={clearRepairNotice} />
        </Card>
      ) : null}

      <Eyebrow>Backup</Eyebrow>
      <Card>
        <Text style={styles.body}>
          Save your whole semester as text, or restore it on another install.
        </Text>
        <Button
          label="Export or import data"
          style={{ marginTop: 14 }}
          onPress={() => router.push('/backup')}
        />
      </Card>

      <Eyebrow>Courses</Eyebrow>
      {courses.map((c) => (
        <Card key={c.id} onPress={() => router.push({ pathname: '/course/[id]', params: { id: c.id } })}>
          <View style={styles.courseRow}>
            <Dot color={c.color} />
            <View style={{ flex: 1 }}>
              <Text style={styles.courseName}>{c.name}</Text>
              <Text style={styles.courseMeta}>
                {c.slots.length} credit{c.slots.length === 1 ? '' : 's'} · {c.totalLectures} classes
              </Text>
            </View>
            <Ionicons name="chevron-forward" size={22} color={C.faint} />
          </View>
        </Card>
      ))}
      <View style={{ paddingHorizontal: S.gutter, gap: 10, marginBottom: 26 }}>
        <Button
          label="Import timetable"
          tone="ghost"
          onPress={() => router.push('/import-timetable')}
        />
      </View>

      <Eyebrow>Official attendance</Eyebrow>
      <Card>
        <Text style={styles.body}>
          {lastReportAsOf
            ? `Last report covered up to ${formatLong(lastReportAsOf)}.`
            : 'No report imported yet. Attach the detailed per-lecture PDF from your portal to reconcile.'}
        </Text>
        <Button
          label="Import attendance report"
          style={{ marginTop: 14 }}
          onPress={() => router.push('/import-report')}
        />
      </Card>

      <Eyebrow>Semester</Eyebrow>
      <Card>
        <Text style={styles.label}>Start date (Monday of week 1)</Text>
        <View style={styles.inputRow}>
          <TextInput
            value={startDraft}
            onChangeText={setStartDraft}
            onBlur={saveStart}
            placeholder="YYYY-MM-DD"
            placeholderTextColor={C.faint}
            style={styles.input}
            autoCapitalize="none"
          />
        </View>
        <Text style={styles.label}>Teaching weeks</Text>
        <View style={styles.inputRow}>
          <TextInput
            value={weeksDraft}
            onChangeText={setWeeksDraft}
            onBlur={() => {
              const n = Number(weeksDraft);
              if (!Number.isFinite(n) || n < 1 || n > 40) {
                setWeeksDraft(`${teachingWeeks}`);
                return;
              }
              setTeachingWeeks(Math.round(n));
            }}
            keyboardType="number-pad"
            style={styles.input}
          />
        </View>
        <Text style={styles.hint}>
          How many weeks the timetable runs. This sets each course&apos;s planned lecture count
          (weekly classes × weeks), so changing it rebuilds the semester.
        </Text>

        <Text style={styles.hint}>
          {schedule.semesterEnd
            ? `Lectures currently run out on ${formatLong(schedule.semesterEnd)}. There is no fixed end date — it moves as lectures are postponed or pulled forward.`
            : 'Add courses to see where the semester lands.'}
        </Text>
      </Card>

      <Card>
        <Text style={styles.label}>Attendance target</Text>
        <View style={styles.targetRow}>
          {[0.75, 0.8, 0.85].map((t) => (
            <Button
              key={t}
              label={`${Math.round(t * 100)}%`}
              tone={target === t ? 'primary' : 'ghost'}
              onPress={() => setTarget(t)}
              style={{ flex: 1 }}
            />
          ))}
        </View>
      </Card>

      <Eyebrow>Google AI Studio key</Eyebrow>
      <Card>
        <Text style={styles.body}>
          {keySaved
            ? 'A key is saved on this device. Paste a new one to replace it.'
            : 'Needed for reading timetables and attendance reports. Stored only on this device.'}
        </Text>
        <View style={styles.inputRow}>
          <TextInput
            value={keyDraft}
            onChangeText={setKeyDraft}
            placeholder="AIza..."
            placeholderTextColor={C.faint}
            style={styles.input}
            autoCapitalize="none"
            autoCorrect={false}
            secureTextEntry
          />
        </View>
        <Button label="Save key" onPress={saveKey} disabled={!keyDraft.trim()} />
      </Card>

      <Eyebrow>Danger zone</Eyebrow>
      <Card>
        <Row
          label="Recalculate lecture counts from timetable"
          onPress={() => {
            const changes = runRepair();
            Alert.alert(
              changes.length ? 'Totals recalculated' : 'Nothing to change',
              changes.length ? changes.join('\n') : 'Every course total already matches.'
            );
          }}
        />
        <Row label="Reset all data" onPress={confirmReset} destructive />
      </Card>
    </Screen>
  );
}

const styles = StyleSheet.create({
  courseRow: { flexDirection: 'row', alignItems: 'center', gap: 14 },
  fixedTitle: { fontSize: 18, fontWeight: '800', color: C.green, marginBottom: 8 },
  line: { fontSize: 14, color: C.text, paddingVertical: 3 },
  courseName: { fontSize: 18, fontWeight: '700', color: C.text },
  courseMeta: { fontSize: 14, color: C.dim, marginTop: 3 },
  body: { fontSize: 15, color: C.dim, lineHeight: 23 },
  label: { fontSize: 15, fontWeight: '700', color: C.text, marginBottom: 10 },
  hint: { fontSize: 13, color: C.faint, lineHeight: 19, marginTop: 10 },
  inputRow: { marginVertical: 10 },
  input: {
    backgroundColor: C.surfaceAlt,
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 14,
    color: C.text,
    fontSize: 16,
  },
  targetRow: { flexDirection: 'row', gap: 8 },
});
