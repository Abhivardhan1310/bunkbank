import React, { useMemo, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useStore, courseMap } from '@/store';
import { C, S } from '@/theme';
import {
  DAY_SHORT,
  addDays,
  fromKey,
  mondayOf,
  prettyTime,
  todayKey,
  weekdayOf,
} from '@/lib/date';
import { cancelledOn, sessionsOn } from '@/lib/schedule';

export default function ScheduleTab() {
  const insets = useSafeAreaInsets();
  const router = useRouter();

  const [weekStart, setWeekStart] = useState(() => mondayOf(todayKey()));
  const [selected, setSelected] = useState(() => todayKey());

  const courses = useStore((s) => s.courses);
  const schedule = useStore((s) => s.schedule);
  const marks = useStore((s) => s.marks);
  const holidays = useStore((s) => s.holidays);

  const byId = useMemo(() => courseMap(courses), [courses]);
  const week = useMemo(
    () => Array.from({ length: 7 }, (_, i) => addDays(weekStart, i)),
    [weekStart]
  );

  const sessions = sessionsOn(schedule, selected);
  const cancelled = cancelledOn(schedule, selected);
  const isHoliday = holidays.includes(selected);
  const today = todayKey();

  const goToday = () => {
    setWeekStart(mondayOf(today));
    setSelected(today);
  };

  return (
    <View style={[styles.screen, { paddingTop: insets.top + 12 }]}>
      <View style={styles.header}>
        <Text style={styles.title}>Schedule</Text>
        <Pressable onPress={goToday} hitSlop={10}>
          <Text style={styles.todayLink}>Today</Text>
        </Pressable>
      </View>

      <View style={styles.strip}>
        <Pressable onPress={() => setWeekStart(addDays(weekStart, -7))} hitSlop={10}>
          <Ionicons name="chevron-back" size={26} color={C.dim} />
        </Pressable>

        <View style={styles.days}>
          {week.map((d) => {
            const active = d === selected;
            const has = (schedule.byDate.get(d)?.length ?? 0) > 0;
            const holiday = holidays.includes(d);
            return (
              <Pressable
                key={d}
                onPress={() => setSelected(d)}
                style={[styles.day, active && styles.dayActive]}
              >
                <Text style={[styles.dayLetter, active && styles.dayLetterActive]}>
                  {DAY_SHORT[weekdayOf(d)][0]}
                </Text>
                <Text style={[styles.dayNum, active && styles.dayNumActive]}>
                  {fromKey(d).getDate()}
                </Text>
                <View
                  style={[
                    styles.tick,
                    {
                      backgroundColor: holiday
                        ? C.amber
                        : has
                          ? active
                            ? C.bg
                            : C.dim
                          : 'transparent',
                    },
                  ]}
                />
              </Pressable>
            );
          })}
        </View>

        <Pressable onPress={() => setWeekStart(addDays(weekStart, 7))} hitSlop={10}>
          <Ionicons name="chevron-forward" size={26} color={C.dim} />
        </Pressable>
      </View>

      <ScrollView
        contentContainerStyle={{ paddingBottom: 40, paddingTop: 6 }}
        showsVerticalScrollIndicator={false}
      >
        {isHoliday ? (
          <View style={styles.banner}>
            <Ionicons name="sunny-outline" size={20} color={C.amber} />
            <Text style={styles.bannerText}>
              Holiday — these lectures moved to the end of the semester
            </Text>
          </View>
        ) : null}

        {sessions.length === 0 && cancelled.length === 0 ? (
          <View style={styles.empty}>
            <Text style={styles.emptyTitle}>No lectures</Text>
            <Text style={styles.emptyBody}>
              Enjoy the day off, or run another weekday&apos;s timetable here.
            </Text>
          </View>
        ) : null}

        {sessions.map((s) => {
          const course = byId.get(s.courseId);
          if (!course) return null;
          const mark = marks[s.key];
          const status = mark
            ? mark.status === 'present'
              ? 'Attended'
              : 'Missed'
            : s.date < today
              ? 'Unmarked'
              : 'Upcoming';
          const tone =
            mark?.status === 'present' ? C.green : mark?.status === 'absent' ? C.red : C.dim;

          return (
            <Pressable
              key={s.key}
              onPress={() => router.push({ pathname: '/day/[date]', params: { date: selected } })}
              style={styles.item}
            >
              <View style={[styles.bar, { backgroundColor: course.color }]} />
              <View style={{ flex: 1, gap: 6 }}>
                <Text style={styles.itemTitle}>{course.name}</Text>
                <Text style={styles.itemMeta}>
                  {prettyTime(s.start)}
                  {s.room ? ` · ${s.room}` : ''}
                  {s.kind === 'extra' ? ' · extra' : ''}
                </Text>
              </View>
              <View style={styles.statusWrap}>
                <View
                  style={[
                    styles.statusChip,
                    { backgroundColor: mark ? 'transparent' : C.surfaceAlt },
                  ]}
                >
                  <Text style={[styles.statusText, { color: tone }]}>{status}</Text>
                </View>
                {mark?.source === 'report' ? (
                  <View style={styles.official}>
                    <Ionicons name="lock-closed" size={11} color={C.blue} />
                    <Text style={styles.officialText}>Official</Text>
                  </View>
                ) : null}
              </View>
            </Pressable>
          );
        })}

        {cancelled.map((c) => {
          const course = byId.get(c.courseId);
          if (!course) return null;
          return (
            <View key={`x_${c.key}`} style={[styles.item, { opacity: 0.5 }]}>
              <View style={[styles.bar, { backgroundColor: C.faint }]} />
              <View style={{ flex: 1, gap: 6 }}>
                <Text style={[styles.itemTitle, styles.struck]}>{course.name}</Text>
                <Text style={styles.itemMeta}>
                  {prettyTime(c.start)} · {c.reason === 'holiday' ? 'holiday' : 'postponed'}
                </Text>
              </View>
            </View>
          );
        })}

        <Pressable
          style={styles.manage}
          onPress={() => router.push({ pathname: '/day/[date]', params: { date: selected } })}
        >
          <Ionicons name="options-outline" size={20} color={C.blue} />
          <Text style={styles.manageText}>Manage this day</Text>
        </Pressable>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: C.bg },
  header: {
    paddingHorizontal: S.gutter,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  title: { fontSize: 40, fontWeight: '800', color: C.text, letterSpacing: -1 },
  todayLink: { color: C.blue, fontSize: 19, fontWeight: '700' },
  strip: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: S.gutter,
    marginBottom: 14,
    gap: 4,
  },
  days: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: C.surface,
    borderRadius: 20,
    paddingVertical: 8,
    paddingHorizontal: 6,
  },
  day: { alignItems: 'center', paddingVertical: 8, paddingHorizontal: 8, borderRadius: 14, gap: 4 },
  dayActive: { backgroundColor: C.text },
  dayLetter: { fontSize: 13, fontWeight: '600', color: C.faint },
  dayLetterActive: { color: C.bg },
  dayNum: { fontSize: 19, fontWeight: '800', color: C.text },
  dayNumActive: { color: C.bg },
  tick: { width: 5, height: 5, borderRadius: 3 },
  banner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginHorizontal: S.gutter,
    marginBottom: 12,
    padding: 14,
    borderRadius: 14,
    backgroundColor: C.amberDim,
  },
  bannerText: { flex: 1, color: C.amber, fontSize: 14, fontWeight: '600' },
  item: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    backgroundColor: C.surface,
    borderRadius: 18,
    marginHorizontal: S.gutter,
    marginBottom: 12,
    padding: 16,
  },
  bar: { width: 4, alignSelf: 'stretch', borderRadius: 2 },
  itemTitle: { fontSize: 18, fontWeight: '700', color: C.text },
  itemMeta: { fontSize: 14, color: C.dim },
  struck: { textDecorationLine: 'line-through', color: C.dim },
  statusWrap: { alignItems: 'flex-end', gap: 5 },
  statusChip: { paddingHorizontal: 12, paddingVertical: 7, borderRadius: 999 },
  statusText: { fontSize: 14, fontWeight: '700' },
  official: { flexDirection: 'row', alignItems: 'center', gap: 3 },
  officialText: { fontSize: 11, color: C.blue, fontWeight: '700' },
  empty: { alignItems: 'center', paddingTop: 40, paddingHorizontal: 40 },
  emptyTitle: { fontSize: 20, fontWeight: '700', color: C.text },
  emptyBody: { fontSize: 15, color: C.dim, textAlign: 'center', marginTop: 6, lineHeight: 22 },
  manage: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginTop: 8,
    padding: 16,
  },
  manageText: { color: C.blue, fontSize: 16, fontWeight: '700' },
});
