import React, { useMemo, useState } from 'react';
import { Alert, Pressable, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { useRouter } from 'expo-router';
import { useStore, courseMap } from '@/store';
import { SwipeCard } from '@/components/SwipeCard';
import { Empty, Button, Ring } from '@/components/ui';
import { C, S } from '@/theme';
import { formatLong, todayKey } from '@/lib/date';
import { computeAllStats, overallPct, pctTone } from '@/lib/stats';
import { cancelledOn, sessionsOn, tailOf } from '@/lib/schedule';
import type { MarkStatus, Session } from '@/types';

export default function Today() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const [undoable, setUndoable] = useState<string[]>([]);

  const courses = useStore((s) => s.courses);
  const schedule = useStore((s) => s.schedule);
  const marks = useStore((s) => s.marks);
  const target = useStore((s) => s.target);
  const holidays = useStore((s) => s.holidays);
  const mark = useStore((s) => s.mark);
  const unmark = useStore((s) => s.unmark);
  const postpone = useStore((s) => s.postpone);

  const date = todayKey();
  const byId = useMemo(() => courseMap(courses), [courses]);
  const stats = useMemo(
    () => computeAllStats(courses, schedule, marks, target),
    [courses, schedule, marks, target]
  );

  const all = sessionsOn(schedule, date);
  const pending = all.filter((s) => !marks[s.key]);
  const cancelled = cancelledOn(schedule, date);
  const isHoliday = holidays.includes(date);
  const done = all.length - pending.length;

  const decide = (session: Session, status: MarkStatus) => {
    Haptics.impactAsync(
      status === 'present'
        ? Haptics.ImpactFeedbackStyle.Light
        : Haptics.ImpactFeedbackStyle.Medium
    );
    mark(session.key, status);
    setUndoable((u) => [...u, session.key]);
  };

  const undo = () => {
    const last = undoable[undoable.length - 1];
    if (!last) return;
    unmark(last);
    setUndoable((u) => u.slice(0, -1));
  };

  const onPostpone = () => {
    const front = pending[0];
    if (!front) return;
    const course = byId.get(front.courseId);
    Alert.alert(
      'Class postponed',
      `This lecture won't count. ${course?.name ?? 'The course'} keeps all ${course?.totalLectures ?? 0} lectures — one more gets added at the end of the semester.`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Postpone',
          onPress: () => {
            postpone(front.key);
            const moved = tailOf(useStore.getState().schedule, front.courseId);
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            if (moved) {
              Alert.alert('Moved to the end', `Added back on ${formatLong(moved.date)}.`);
            }
          },
        },
      ]
    );
  };

  if (courses.length === 0) {
    return (
      <View style={[styles.screen, { paddingTop: insets.top + 12 }]}>
        <Header date={date} pct={0} target={target} />
        <Empty
          title="No courses yet"
          body="Import your timetable and BunkBank will lay out the whole semester for you."
          action={
            <View style={{ paddingHorizontal: S.gutter, gap: 10 }}>
              <Button label="Import timetable" onPress={() => router.push('/import-timetable')} />
              <Button label="Add manually" tone="ghost" onPress={() => router.push('/setup')} />
            </View>
          }
        />
      </View>
    );
  }

  return (
    <View style={[styles.screen, { paddingTop: insets.top + 12 }]}>
      <Header date={date} pct={overallPct(stats)} target={target} />

      {all.length > 0 ? (
        <Text style={styles.counter}>
          {done + 1 > all.length ? all.length : done + 1} / {all.length}
        </Text>
      ) : (
        <View style={{ height: 22 }} />
      )}

      <View style={styles.deck}>
        {pending.length === 0 ? (
          <View style={styles.doneBox}>
            <Ionicons
              name={isHoliday ? 'sunny-outline' : 'checkmark-done-circle-outline'}
              size={56}
              color={C.green}
            />
            <Text style={styles.doneTitle}>
              {isHoliday ? 'Holiday' : all.length ? 'All marked' : 'No lectures today'}
            </Text>
            <Text style={styles.doneBody}>
              {isHoliday
                ? `${cancelled.length} lecture${cancelled.length === 1 ? '' : 's'} pushed to the end of the semester.`
                : all.length
                  ? 'Nothing left to mark today.'
                  : 'Enjoy the day off, or add an extra lecture if one comes up.'}
            </Text>
            <Pressable onPress={() => router.push({ pathname: '/day/[date]', params: { date } })} style={styles.linkBtn}>
              <Text style={styles.link}>Open today in Schedule</Text>
            </Pressable>
          </View>
        ) : (
          pending
            .slice(0, 3)
            .map((session, i) => {
              const course = byId.get(session.courseId);
              if (!course) return null;
              const st = stats.get(course.id);
              return (
                <SwipeCard
                  key={session.key}
                  session={session}
                  course={course}
                  index={i}
                  subtitle={
                    st
                      ? st.bunksRemaining > 0
                        ? `${st.bunksRemaining} bunk${st.bunksRemaining === 1 ? '' : 's'} remaining`
                        : 'Must attend all remaining'
                      : ''
                  }
                  onDecide={(status) => decide(session, status)}
                />
              );
            })
            .reverse()
        )}
      </View>

      <View style={styles.actions}>
        <View style={styles.legend}>
          <View style={styles.legendSide}>
            <Ionicons name="arrow-back" size={18} color={C.red} />
            <Text style={[styles.legendText, { color: C.red }]}>Missed</Text>
          </View>
          <Pressable onPress={onPostpone} disabled={pending.length === 0} hitSlop={10}>
            <Text
              style={[
                styles.postponeLink,
                { opacity: pending.length === 0 ? 0.3 : 1 },
              ]}
            >
              Class postponed
            </Text>
          </Pressable>
          <View style={styles.legendSide}>
            <Text style={[styles.legendText, { color: C.green }]}>Attended</Text>
            <Ionicons name="arrow-forward" size={18} color={C.green} />
          </View>
        </View>

        <View style={styles.buttons}>
          <CircleButton
            color={C.red}
            icon="close"
            disabled={pending.length === 0}
            onPress={() => pending[0] && decide(pending[0], 'absent')}
          />
          <Pressable onPress={undo} disabled={undoable.length === 0} hitSlop={12}>
            <Ionicons
              name="arrow-undo-outline"
              size={30}
              color={undoable.length ? C.dim : C.border}
            />
          </Pressable>
          <CircleButton
            color={C.green}
            icon="checkmark"
            disabled={pending.length === 0}
            onPress={() => pending[0] && decide(pending[0], 'present')}
          />
        </View>
      </View>
    </View>
  );
}

function Header({ date, pct, target }: { date: string; pct: number; target: number }) {
  const tone = pctTone(pct, target);
  const color = tone === 'good' ? C.green : tone === 'warn' ? C.amber : C.red;
  return (
    <View style={styles.header}>
      <View style={{ flex: 1 }}>
        <Text style={styles.eyebrow}>{formatLong(date).toUpperCase()}</Text>
        <Text style={styles.title}>Today</Text>
      </View>
      <Ring pct={pct} color={color} size={82} stroke={8} />
    </View>
  );
}

function CircleButton({
  color,
  icon,
  onPress,
  disabled,
}: {
  color: string;
  icon: 'close' | 'checkmark';
  onPress: () => void;
  disabled?: boolean;
}) {
  return (
    <Pressable
      onPress={disabled ? undefined : onPress}
      style={({ pressed }) => [
        styles.circle,
        { borderColor: color, opacity: disabled ? 0.3 : pressed ? 0.6 : 1 },
      ]}
      accessibilityRole="button"
      accessibilityLabel={icon === 'checkmark' ? 'Mark attended' : 'Mark missed'}
    >
      <Ionicons name={icon} size={38} color={color} />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: C.bg },
  header: {
    paddingHorizontal: S.gutter,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
  },
  eyebrow: {
    fontSize: 14,
    fontWeight: '700',
    color: C.dim,
    letterSpacing: 1.6,
    marginBottom: 4,
  },
  title: { fontSize: 44, fontWeight: '800', color: C.text, letterSpacing: -1.2 },
  counter: {
    textAlign: 'right',
    paddingHorizontal: S.gutter,
    color: C.dim,
    fontSize: 16,
    fontWeight: '700',
    marginTop: 8,
  },
  deck: { flex: 1, marginTop: 10, marginBottom: 12 },
  actions: { paddingHorizontal: S.gutter, paddingBottom: 8 },
  legend: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 14,
  },
  legendSide: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  legendText: { fontSize: 17, fontWeight: '700' },
  postponeLink: {
    color: C.dim,
    fontSize: 16,
    fontWeight: '600',
    textDecorationLine: 'underline',
  },
  buttons: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
  },
  circle: {
    width: 86,
    height: 86,
    borderRadius: 43,
    borderWidth: 3,
    alignItems: 'center',
    justifyContent: 'center',
  },
  doneBox: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 32 },
  doneTitle: { fontSize: 26, fontWeight: '800', color: C.text, marginTop: 16 },
  doneBody: { fontSize: 16, color: C.dim, textAlign: 'center', marginTop: 8, lineHeight: 23 },
  linkBtn: { marginTop: 22 },
  link: { color: C.blue, fontSize: 16, fontWeight: '700' },
});
