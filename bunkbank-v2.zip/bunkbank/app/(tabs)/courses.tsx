import React, { useMemo } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { useStore } from '@/store';
import { Card, Dot, Empty, Pill, Ring, Screen, Title, Button } from '@/components/ui';
import { C, S } from '@/theme';
import { computeAllStats, pctTone } from '@/lib/stats';

export default function Courses() {
  const router = useRouter();
  const courses = useStore((s) => s.courses);
  const schedule = useStore((s) => s.schedule);
  const marks = useStore((s) => s.marks);
  const target = useStore((s) => s.target);

  const stats = useMemo(
    () => computeAllStats(courses, schedule, marks, target),
    [courses, schedule, marks, target]
  );

  if (courses.length === 0) {
    return (
      <Screen>
        <Title>Courses</Title>
        <Empty
          title="Nothing to track yet"
          body="Add courses and BunkBank works out how many lectures you can afford to miss."
          action={
            <View style={{ paddingHorizontal: S.gutter }}>
              <Button label="Import timetable" onPress={() => router.push('/import-timetable')} />
            </View>
          }
        />
      </Screen>
    );
  }

  return (
    <Screen>
      <Title>Courses</Title>
      {courses.map((course) => {
        const st = stats.get(course.id)!;
        const tone = pctTone(st.currentPct, target);
        const ringColor = tone === 'good' ? C.green : tone === 'warn' ? C.amber : C.red;
        const credits = course.slots.length;

        return (
          <Card key={course.id} onPress={() => router.push({ pathname: '/course/[id]', params: { id: course.id } })}>
            <View style={styles.row}>
              <Ring pct={st.currentPct} color={ringColor} size={92} stroke={8} />
              <View style={styles.info}>
                <View style={styles.nameRow}>
                  <Dot color={course.color} />
                  <Text style={styles.name}>{course.name}</Text>
                </View>
                <Text style={styles.meta}>
                  {credits} cr · {st.attended}/{st.held} attended · {st.total} total
                </Text>
                <View style={styles.pills}>
                  <Pill
                    label={`${st.bunksRemaining} bunk${st.bunksRemaining === 1 ? '' : 's'} left`}
                    tone={st.bunksRemaining > 4 ? 'good' : st.bunksRemaining > 0 ? 'warn' : 'bad'}
                  />
                  <Pill label={`must attend ${st.mustAttend}`} />
                </View>
              </View>
            </View>
            <Text style={[styles.footer, { color: ringColor }]}>
              {st.bunksRemaining > 0
                ? `You can still skip ${st.bunksRemaining} more`
                : `Attend every remaining lecture to reach ${Math.round(target * 100)}%`}
            </Text>
          </Card>
        );
      })}
    </Screen>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', gap: 16 },
  info: { flex: 1, gap: 8 },
  nameRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  name: { flex: 1, fontSize: 21, fontWeight: '800', color: C.text, letterSpacing: -0.4 },
  meta: { fontSize: 15, color: C.dim },
  pills: { flexDirection: 'row', gap: 8, flexWrap: 'wrap' },
  footer: { marginTop: 14, fontSize: 16, fontWeight: '700' },
});
