import React, { useMemo, useState } from 'react';
import { Alert, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useStore } from '@/store';
import { Button, Card, Eyebrow, Pill, Ring, Screen } from '@/components/ui';
import { C, S } from '@/theme';
import { DAY_NAMES, formatShort, prettyTime, todayKey } from '@/lib/date';
import { computeCourseStats, pctTone } from '@/lib/stats';

export default function CourseDetail() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();

  const course = useStore((s) => s.courses.find((c) => c.id === id));
  const schedule = useStore((s) => s.schedule);
  const marks = useStore((s) => s.marks);
  const target = useStore((s) => s.target);
  const updateCourse = useStore((s) => s.updateCourse);
  const removeCourse = useStore((s) => s.removeCourse);

  const [totalDraft, setTotalDraft] = useState(() => `${course?.totalLectures ?? 0}`);

  const stats = useMemo(
    () => (course ? computeCourseStats(course, schedule, marks, target) : null),
    [course, schedule, marks, target]
  );

  if (!course || !stats) {
    return (
      <Screen>
        <Text style={styles.missing}>That course is gone.</Text>
      </Screen>
    );
  }

  const sessions = schedule.byCourse.get(course.id) ?? [];
  const today = todayKey();
  const history = sessions.filter((s) => marks[s.key] || s.date < today).reverse();
  const tone = pctTone(stats.currentPct, target);
  const ringColor = tone === 'good' ? C.green : tone === 'warn' ? C.amber : C.red;

  const saveTotal = () => {
    const n = Number(totalDraft);
    if (!Number.isFinite(n) || n < 1) {
      Alert.alert('Check the number', 'Enter how many lectures this course has in the semester.');
      setTotalDraft(`${course.totalLectures}`);
      return;
    }
    updateCourse(course.id, { totalLectures: Math.round(n) });
  };

  const confirmDelete = () => {
    Alert.alert(
      `Delete ${course.name}?`,
      'The course and all its attendance records will be removed.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: () => {
            removeCourse(course.id);
            router.back();
          },
        },
      ]
    );
  };

  return (
    <Screen>
      <View style={styles.head}>
        <Pressable onPress={() => router.back()} hitSlop={12}>
          <Ionicons name="chevron-back" size={30} color={C.text} />
        </Pressable>
        <View style={{ flex: 1 }}>
          <Text style={styles.name}>{course.name}</Text>
          {course.code ? <Text style={styles.code}>{course.code}</Text> : null}
        </View>
      </View>

      <Card>
        <View style={styles.statRow}>
          <Ring pct={stats.currentPct} color={ringColor} size={96} stroke={9} />
          <View style={{ flex: 1, gap: 8 }}>
            <Text style={styles.big}>
              {stats.attended}/{stats.held}
            </Text>
            <Text style={styles.meta}>attended of {stats.total} total</Text>
            <View style={styles.pills}>
              <Pill
                label={`${stats.bunksRemaining} bunks left`}
                tone={stats.bunksRemaining > 4 ? 'good' : stats.bunksRemaining > 0 ? 'warn' : 'bad'}
              />
              <Pill label={`must attend ${stats.mustAttend}`} />
            </View>
          </View>
        </View>
        {stats.unmarkedPast > 0 ? (
          <Text style={styles.warn}>
            {stats.unmarkedPast} past lecture{stats.unmarkedPast === 1 ? '' : 's'} still unmarked.
          </Text>
        ) : null}
      </Card>

      <Eyebrow>Weekly slots</Eyebrow>
      <Card>
        {course.slots.map((s, i) => (
          <View key={i} style={styles.slot}>
            <Text style={styles.slotDay}>{DAY_NAMES[s.day]}</Text>
            <Text style={styles.slotTime}>
              {prettyTime(s.start)} – {prettyTime(s.end)}
              {s.room ? ` · ${s.room}` : ''}
            </Text>
          </View>
        ))}
      </Card>

      <Eyebrow>Semester total</Eyebrow>
      <Card>
        <Text style={styles.body}>
          The number of lectures this course gets. Postponing pushes one to the end; adding an extra
          takes one off the end. This number only moves if you change it or an official report says
          otherwise.
        </Text>
        <View style={styles.inputRow}>
          <TextInput
            value={totalDraft}
            onChangeText={setTotalDraft}
            onBlur={saveTotal}
            keyboardType="number-pad"
            style={styles.input}
          />
        </View>
        {stats.lastDate ? (
          <Text style={styles.hint}>Last lecture currently falls on {formatShort(stats.lastDate)}.</Text>
        ) : null}
      </Card>

      <Eyebrow>History</Eyebrow>
      {history.length === 0 ? (
        <Card>
          <Text style={styles.body}>Nothing marked yet.</Text>
        </Card>
      ) : null}
      {history.slice(0, 60).map((s) => {
        const mark = marks[s.key];
        return (
          <View key={s.key} style={styles.histRow}>
            <Text style={styles.histDate}>{formatShort(s.date)}</Text>
            <Text style={styles.histTime}>{prettyTime(s.start)}</Text>
            <View style={{ flex: 1 }} />
            {mark?.source === 'report' ? (
              <Ionicons name="lock-closed" size={12} color={C.blue} style={{ marginRight: 6 }} />
            ) : null}
            <Text
              style={{
                color: !mark ? C.faint : mark.status === 'present' ? C.green : C.red,
                fontWeight: '700',
                fontSize: 14,
              }}
            >
              {!mark ? 'Unmarked' : mark.status === 'present' ? 'Attended' : 'Missed'}
            </Text>
          </View>
        );
      })}

      <View style={{ paddingHorizontal: S.gutter, marginTop: 24 }}>
        <Button label="Delete course" tone="danger" onPress={confirmDelete} />
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  head: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: S.gutter,
    marginBottom: 20,
  },
  name: { fontSize: 26, fontWeight: '800', color: C.text, letterSpacing: -0.5 },
  code: { fontSize: 14, color: C.dim, marginTop: 3 },
  missing: { color: C.dim, padding: S.gutter, fontSize: 16 },
  statRow: { flexDirection: 'row', alignItems: 'center', gap: 18 },
  big: { fontSize: 30, fontWeight: '800', color: C.text },
  meta: { fontSize: 14, color: C.dim },
  pills: { flexDirection: 'row', gap: 8, flexWrap: 'wrap' },
  warn: { color: C.amber, fontSize: 14, marginTop: 14, fontWeight: '600' },
  slot: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 11,
    gap: 12,
  },
  slotDay: { fontSize: 16, fontWeight: '700', color: C.text },
  slotTime: { fontSize: 15, color: C.dim, flexShrink: 1, textAlign: 'right' },
  body: { fontSize: 15, color: C.dim, lineHeight: 23 },
  hint: { fontSize: 13, color: C.faint, marginTop: 4 },
  inputRow: { marginVertical: 12 },
  input: {
    backgroundColor: C.surfaceAlt,
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 14,
    color: C.text,
    fontSize: 17,
    fontWeight: '700',
  },
  histRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 11,
    paddingHorizontal: S.gutter + 4,
  },
  histDate: { fontSize: 15, color: C.text, fontWeight: '600', width: 66 },
  histTime: { fontSize: 14, color: C.dim },
});
