import React, { useMemo, useState } from 'react';
import { Alert, Modal, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { useStore, courseMap } from '@/store';
import { Button, Card, Dot, Eyebrow, Screen } from '@/components/ui';
import { C, S } from '@/theme';
import { DAY_NAMES, formatLong, prettyTime, weekdayOf } from '@/lib/date';
import { cancelledOn, sessionsOn, tailOf, teachingWeekdays, weekdayTemplate } from '@/lib/schedule';
import type { Weekday } from '@/types';

export default function DayScreen() {
  const { date } = useLocalSearchParams<{ date: string }>();
  const router = useRouter();
  const day = date!;

  const courses = useStore((s) => s.courses);
  const schedule = useStore((s) => s.schedule);
  const marks = useStore((s) => s.marks);
  const holidays = useStore((s) => s.holidays);
  const extras = useStore((s) => s.extras);
  const postpone = useStore((s) => s.postpone);
  const unpostpone = useStore((s) => s.unpostpone);
  const toggleHoliday = useStore((s) => s.toggleHoliday);
  const cloneWeekday = useStore((s) => s.cloneWeekday);
  const removeClone = useStore((s) => s.removeClone);
  const removeExtra = useStore((s) => s.removeExtra);
  const addExtra = useStore((s) => s.addExtra);

  const [pickDay, setPickDay] = useState(false);
  const [pickExtra, setPickExtra] = useState(false);
  const [extraTime, setExtraTime] = useState('09:00');

  const byId = useMemo(() => courseMap(courses), [courses]);
  const sessions = sessionsOn(schedule, day);
  const cancelled = cancelledOn(schedule, day);
  const isHoliday = holidays.includes(day);
  const dayExtras = extras.filter((e) => e.date === day);
  const clones = [...new Set(dayExtras.map((e) => e.cloneId).filter(Boolean))] as string[];
  const weekdays = teachingWeekdays(courses).filter((d) => d !== weekdayOf(day));

  const doClone = (source: Weekday) => {
    const n = cloneWeekday(day, source);
    setPickDay(false);
    if (n === 0) {
      Alert.alert('Nothing to add', `Those lectures are already on this day.`);
      return;
    }
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    Alert.alert(
      `${DAY_NAMES[source]} timetable added`,
      `${n} lecture${n === 1 ? '' : 's'} added here and removed from the end of the semester, so every course keeps its original total.`
    );
  };

  const doPostpone = (key: string, courseId: string) => {
    postpone(key);
    const moved = tailOf(useStore.getState().schedule, courseId);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    if (moved) Alert.alert('Moved to the end', `Added back on ${formatLong(moved.date)}.`);
  };

  return (
    <Screen>
      <View style={styles.head}>
        <Pressable onPress={() => router.back()} hitSlop={12}>
          <Ionicons name="chevron-back" size={30} color={C.text} />
        </Pressable>
        <View style={{ flex: 1 }}>
          <Text style={styles.date}>{formatLong(day)}</Text>
          <Text style={styles.sub}>
            {sessions.length} lecture{sessions.length === 1 ? '' : 's'}
            {isHoliday ? ' · holiday' : ''}
          </Text>
        </View>
      </View>

      <Eyebrow>Lectures</Eyebrow>

      {sessions.length === 0 && cancelled.length === 0 ? (
        <Card>
          <Text style={styles.blank}>Nothing scheduled on this day.</Text>
        </Card>
      ) : null}

      {sessions.map((s) => {
        const course = byId.get(s.courseId);
        if (!course) return null;
        const mark = marks[s.key];
        const isClone = !!s.cloneId;
        return (
          <Card key={s.key} accent={course.color}>
            <View style={styles.itemRow}>
              <View style={{ flex: 1, gap: 5 }}>
                <Text style={styles.itemTitle}>{course.name}</Text>
                <Text style={styles.itemMeta}>
                  {prettyTime(s.start)} – {prettyTime(s.end)}
                  {s.room ? ` · ${s.room}` : ''}
                </Text>
                <Text style={styles.index}>
                  Lecture {s.index} of {course.totalLectures}
                  {isClone && s.sourceDay !== undefined
                    ? ` · from ${DAY_NAMES[s.sourceDay]}`
                    : s.kind === 'extra'
                      ? ' · extra'
                      : ''}
                </Text>
              </View>
              {mark ? (
                <Text
                  style={{
                    color: mark.status === 'present' ? C.green : C.red,
                    fontWeight: '700',
                  }}
                >
                  {mark.status === 'present' ? 'Attended' : 'Missed'}
                </Text>
              ) : null}
            </View>

            <View style={styles.actions}>
              <Action
                icon="return-down-forward-outline"
                label="Postpone"
                onPress={() => doPostpone(s.key, s.courseId)}
              />
              {s.kind === 'extra' ? (
                <Action
                  icon="trash-outline"
                  label="Remove"
                  tone={C.red}
                  onPress={() => {
                    const extra = dayExtras.find(
                      (e) => e.courseId === s.courseId && e.start === s.start
                    );
                    if (extra) removeExtra(extra.id);
                  }}
                />
              ) : null}
            </View>
          </Card>
        );
      })}

      {cancelled.map((c) => {
        const course = byId.get(c.courseId);
        if (!course) return null;
        return (
          <Card key={`c_${c.key}`}>
            <View style={styles.itemRow}>
              <View style={{ flex: 1, gap: 5 }}>
                <Text style={[styles.itemTitle, styles.struck]}>{course.name}</Text>
                <Text style={styles.itemMeta}>
                  {prettyTime(c.start)} · {c.reason === 'holiday' ? 'Holiday' : 'Postponed'}
                </Text>
              </View>
            </View>
            {c.reason === 'postponed' ? (
              <View style={styles.actions}>
                <Action
                  icon="arrow-undo-outline"
                  label="Put it back"
                  onPress={() => unpostpone(c.key)}
                />
              </View>
            ) : null}
          </Card>
        );
      })}

      <Eyebrow>Add lectures</Eyebrow>

      <View style={{ paddingHorizontal: S.gutter, gap: 10, marginBottom: 22 }}>
        <Button
          label="Run another weekday's timetable"
          tone="ghost"
          onPress={() => setPickDay(true)}
        />
        <Button label="Add one extra lecture" tone="ghost" onPress={() => setPickExtra(true)} />
        <Text style={styles.note}>
          Anything added here is pulled forward from the end of the semester, so course totals never
          change.
        </Text>
      </View>

      {clones.length ? (
        <>
          <Eyebrow>Cloned days</Eyebrow>
          {clones.map((id) => {
            const items = dayExtras.filter((e) => e.cloneId === id);
            const src = items[0]?.sourceDay;
            return (
              <Card key={id}>
                <View style={styles.itemRow}>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.itemTitle}>
                      {src !== undefined ? DAY_NAMES[src] : 'Cloned'} timetable
                    </Text>
                    <Text style={styles.itemMeta}>{items.length} lectures</Text>
                  </View>
                  <Pressable onPress={() => removeClone(id)} hitSlop={10}>
                    <Text style={{ color: C.red, fontWeight: '700' }}>Undo</Text>
                  </Pressable>
                </View>
              </Card>
            );
          })}
        </>
      ) : null}

      <Eyebrow>Day</Eyebrow>
      <View style={{ paddingHorizontal: S.gutter }}>
        <Button
          label={isHoliday ? 'Remove holiday' : 'Mark as holiday'}
          tone={isHoliday ? 'ghost' : 'danger'}
          onPress={() => toggleHoliday(day)}
        />
      </View>

      <WeekdayPicker
        visible={pickDay}
        weekdays={weekdays}
        courses={courses}
        onPick={doClone}
        onClose={() => setPickDay(false)}
      />

      <ExtraPicker
        visible={pickExtra}
        time={extraTime}
        setTime={setExtraTime}
        courses={courses}
        onPick={(courseId) => {
          addExtra({
            date: day,
            courseId,
            start: extraTime,
            end: bumpHour(extraTime),
          });
          setPickExtra(false);
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        }}
        onClose={() => setPickExtra(false)}
      />
    </Screen>
  );
}

function Action({
  icon,
  label,
  onPress,
  tone = C.dim,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
  onPress: () => void;
  tone?: string;
}) {
  return (
    <Pressable onPress={onPress} style={styles.action} hitSlop={6}>
      <Ionicons name={icon} size={17} color={tone} />
      <Text style={[styles.actionLabel, { color: tone }]}>{label}</Text>
    </Pressable>
  );
}

function WeekdayPicker({
  visible,
  weekdays,
  courses,
  onPick,
  onClose,
}: {
  visible: boolean;
  weekdays: Weekday[];
  courses: ReturnType<typeof useStore.getState>['courses'];
  onPick: (d: Weekday) => void;
  onClose: () => void;
}) {
  return (
    <Sheet visible={visible} onClose={onClose} title="Which day's lectures?">
      {weekdays.length === 0 ? (
        <Text style={styles.blank}>No other weekday has lectures.</Text>
      ) : null}
      {weekdays.map((d) => {
        const t = weekdayTemplate(courses, d);
        return (
          <Pressable key={d} style={styles.pickRow} onPress={() => onPick(d)}>
            <View style={{ flex: 1 }}>
              <Text style={styles.pickTitle}>{DAY_NAMES[d]}</Text>
              <Text style={styles.pickMeta}>
                {t.length} lecture{t.length === 1 ? '' : 's'} ·{' '}
                {t.map((x) => prettyTime(x.start)).join(', ')}
              </Text>
            </View>
            <Ionicons name="chevron-forward" size={22} color={C.faint} />
          </Pressable>
        );
      })}
    </Sheet>
  );
}

function ExtraPicker({
  visible,
  courses,
  time,
  setTime,
  onPick,
  onClose,
}: {
  visible: boolean;
  courses: ReturnType<typeof useStore.getState>['courses'];
  time: string;
  setTime: (t: string) => void;
  onPick: (courseId: string) => void;
  onClose: () => void;
}) {
  return (
    <Sheet visible={visible} onClose={onClose} title="Add one lecture">
      <View style={styles.timeRow}>
        <Text style={styles.pickMeta}>Starts at</Text>
        <TextInput
          value={time}
          onChangeText={setTime}
          placeholder="09:00"
          placeholderTextColor={C.faint}
          style={styles.timeInput}
          keyboardType="numbers-and-punctuation"
          maxLength={5}
        />
      </View>
      {courses.map((c) => (
        <Pressable key={c.id} style={styles.pickRow} onPress={() => onPick(c.id)}>
          <Dot color={c.color} />
          <Text style={[styles.pickTitle, { flex: 1, marginLeft: 12 }]}>{c.name}</Text>
          <Ionicons name="add" size={24} color={C.blue} />
        </Pressable>
      ))}
    </Sheet>
  );
}

function Sheet({
  visible,
  onClose,
  title,
  children,
}: {
  visible: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <Pressable style={styles.backdrop} onPress={onClose} />
      <View style={styles.sheet}>
        <View style={styles.grabber} />
        <Text style={styles.sheetTitle}>{title}</Text>
        {children}
        <Button label="Cancel" tone="ghost" onPress={onClose} style={{ marginTop: 14 }} />
      </View>
    </Modal>
  );
}

function bumpHour(hhmm: string): string {
  const [h, m] = hhmm.split(':').map(Number);
  const nh = (Number.isFinite(h) ? h + 1 : 10) % 24;
  return `${`${nh}`.padStart(2, '0')}:${`${Number.isFinite(m) ? m : 0}`.padStart(2, '0')}`;
}

const styles = StyleSheet.create({
  head: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: S.gutter,
    marginBottom: 22,
  },
  date: { fontSize: 26, fontWeight: '800', color: C.text, letterSpacing: -0.5 },
  sub: { fontSize: 15, color: C.dim, marginTop: 3 },
  itemRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 12 },
  itemTitle: { fontSize: 18, fontWeight: '700', color: C.text },
  itemMeta: { fontSize: 14, color: C.dim },
  index: { fontSize: 13, color: C.faint },
  struck: { textDecorationLine: 'line-through', color: C.dim },
  actions: { flexDirection: 'row', gap: 20, marginTop: 14 },
  action: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  actionLabel: { fontSize: 15, fontWeight: '600' },
  note: { fontSize: 13, color: C.faint, lineHeight: 19, marginTop: 4 },
  blank: { color: C.dim, fontSize: 15 },
  backdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.65)' },
  sheet: {
    backgroundColor: C.surface,
    borderTopLeftRadius: 26,
    borderTopRightRadius: 26,
    padding: 20,
    paddingBottom: 34,
  },
  grabber: {
    width: 40,
    height: 4,
    borderRadius: 2,
    backgroundColor: C.border,
    alignSelf: 'center',
    marginBottom: 16,
  },
  sheetTitle: { fontSize: 21, fontWeight: '800', color: C.text, marginBottom: 14 },
  pickRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 15,
    borderTopWidth: 1,
    borderTopColor: C.border,
  },
  pickTitle: { fontSize: 17, fontWeight: '700', color: C.text },
  pickMeta: { fontSize: 14, color: C.dim, marginTop: 3 },
  timeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingBottom: 12,
  },
  timeInput: {
    backgroundColor: C.surfaceAlt,
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 10,
    color: C.text,
    fontSize: 17,
    fontWeight: '700',
    minWidth: 90,
    textAlign: 'center',
  },
});
