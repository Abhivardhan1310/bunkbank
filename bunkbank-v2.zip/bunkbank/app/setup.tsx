import React, { useState } from 'react';
import { Alert, StyleSheet, Text, TextInput, View } from 'react-native';
import { useRouter } from 'expo-router';
import { useStore } from '@/store';
import { Button, Card, Screen } from '@/components/ui';
import { C, S } from '@/theme';
import { isValidKey, mondayOf, todayKey } from '@/lib/date';

export default function Setup() {
  const router = useRouter();
  const setSemesterStart = useStore((s) => s.setSemesterStart);
  const setOnboarded = useStore((s) => s.setOnboarded);
  const semesterStart = useStore((s) => s.semesterStart);

  const [start, setStart] = useState(semesterStart || mondayOf(todayKey()));

  const proceed = (then: 'import' | 'skip') => {
    if (!isValidKey(start)) {
      Alert.alert('Check the date', 'Semester start must be YYYY-MM-DD.');
      return;
    }
    setSemesterStart(mondayOf(start));
    setOnboarded(true);
    if (then === 'import') router.replace('/import-timetable');
    else router.replace('/(tabs)');
  };

  return (
    <Screen>
      <View style={{ paddingHorizontal: S.gutter, marginBottom: 26 }}>
        <Text style={styles.kicker}>BunkBank</Text>
        <Text style={styles.title}>Set up your semester</Text>
        <Text style={styles.body}>
          Two things and you are tracking: when the semester started, and what you are studying.
        </Text>
      </View>

      <Card>
        <Text style={styles.label}>Semester start date (Monday of week 1)</Text>
        <TextInput
          value={start}
          onChangeText={setStart}
          placeholder="YYYY-MM-DD"
          placeholderTextColor={C.faint}
          style={styles.input}
          autoCapitalize="none"
        />
        <Text style={styles.hint}>
          There is no end date to set. The semester ends when each course runs out of lectures, and
          that date shifts as classes are postponed or pulled forward.
        </Text>
      </Card>

      <View style={{ paddingHorizontal: S.gutter, gap: 10, marginTop: 10 }}>
        <Button label="Import my timetable" onPress={() => proceed('import')} />
        <Button label="I'll add courses later" tone="ghost" onPress={() => proceed('skip')} />
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  kicker: {
    fontSize: 14,
    fontWeight: '700',
    color: C.blue,
    letterSpacing: 1.6,
    textTransform: 'uppercase',
    marginBottom: 8,
  },
  title: { fontSize: 36, fontWeight: '800', color: C.text, letterSpacing: -1, marginBottom: 12 },
  body: { fontSize: 16, color: C.dim, lineHeight: 24 },
  label: { fontSize: 15, fontWeight: '700', color: C.text, marginBottom: 12 },
  input: {
    backgroundColor: C.surfaceAlt,
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 14,
    color: C.text,
    fontSize: 17,
  },
  hint: { fontSize: 13, color: C.faint, lineHeight: 20, marginTop: 12 },
});
