import React, { useState } from 'react';
import { Alert, Pressable, StyleSheet, Text, View } from 'react-native';
import * as DocumentPicker from 'expo-document-picker';
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system/legacy';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useStore } from '@/store';
import { Button, Card, Screen } from '@/components/ui';
import { C, S } from '@/theme';
import { GeminiError, parseTimetable, type ParsedCourse } from '@/lib/gemini';
import { nextColor } from '@/theme';
import type { Course, Weekday } from '@/types';

/** Default semester length in weeks, used to turn credits into a lecture budget. */
const WEEKS = 15;

export default function ImportTimetable() {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const replaceCourses = useStore((s) => s.replaceCourses);
  const setOnboarded = useStore((s) => s.setOnboarded);

  const handle = async (base64: string, mime: string) => {
    setBusy(true);
    setError('');
    try {
      const parsed = await parseTimetable(base64, mime);
      if (parsed.length === 0) {
        setError("Couldn't read any courses. Try a sharper photo or the PDF version.");
        return;
      }
      const courses: Course[] = parsed.map((p: ParsedCourse, i) => {
        const slots = p.slots.map((s) => ({
          day: s.day as Weekday,
          start: s.start,
          end: s.end,
          room: s.room ?? undefined,
        }));
        const perWeek = slots.length || p.credits || 1;
        return {
          id: `c_${Date.now().toString(36)}_${i}`,
          name: p.name,
          code: p.code ?? undefined,
          color: nextColor(i),
          slots,
          totalLectures: perWeek * WEEKS,
        };
      });
      replaceCourses(courses);
      setOnboarded(true);
      Alert.alert(
        'Timetable imported',
        `${courses.length} courses. Check the lecture totals in Settings — they default to ${WEEKS} weeks.`,
        [{ text: 'Done', onPress: () => router.replace('/(tabs)') }]
      );
    } catch (e) {
      setError(e instanceof GeminiError ? e.message : 'Something went wrong reading that file.');
    } finally {
      setBusy(false);
    }
  };

  const pickFile = async () => {
    const res = await DocumentPicker.getDocumentAsync({
      type: ['application/pdf', 'image/*'],
      copyToCacheDirectory: true,
    });
    if (res.canceled || !res.assets?.[0]) return;
    const f = res.assets[0];
    if (f.size && f.size > 15 * 1024 * 1024) {
      setError('Please use a file under 15 MB (a single-page timetable is ideal).');
      return;
    }
    const base64 = await FileSystem.readAsStringAsync(f.uri, {
      encoding: FileSystem.EncodingType.Base64,
    });
    await handle(base64, f.mimeType ?? 'application/pdf');
  };

  const takePhoto = async () => {
    const perm = await ImagePicker.requestCameraPermissionsAsync();
    if (!perm.granted) {
      setError('Camera access is off. Turn it on in your phone settings to snap a timetable.');
      return;
    }
    const res = await ImagePicker.launchCameraAsync({ quality: 0.7, base64: true });
    if (res.canceled || !res.assets?.[0]?.base64) return;
    await handle(res.assets[0].base64, 'image/jpeg');
  };

  return (
    <Screen>
      <View style={styles.head}>
        <Pressable onPress={() => router.back()} hitSlop={12}>
          <Ionicons name="close" size={30} color={C.text} />
        </Pressable>
        <Text style={styles.title}>Import timetable</Text>
      </View>

      <Card>
        <Text style={styles.body}>
          Attach a photo or PDF of your class timetable. BunkBank reads the courses and lays out
          every lecture for the semester.
        </Text>
      </Card>

      {error ? (
        <Card>
          <Text style={styles.error}>{error}</Text>
        </Card>
      ) : null}

      <View style={{ paddingHorizontal: S.gutter, gap: 10 }}>
        <Button label="Choose photo or PDF" onPress={pickFile} loading={busy} />
        <Button label="Take a photo" tone="ghost" onPress={takePhoto} disabled={busy} />
      </View>

      <Text style={styles.note}>
        Importing replaces every course you have now. Attendance you have already marked is kept
        only for courses that survive the import.
      </Text>
    </Screen>
  );
}

const styles = StyleSheet.create({
  head: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    paddingHorizontal: S.gutter,
    marginBottom: 22,
  },
  title: { fontSize: 28, fontWeight: '800', color: C.text, letterSpacing: -0.6 },
  body: { fontSize: 15, color: C.dim, lineHeight: 23 },
  error: { fontSize: 15, color: C.red, lineHeight: 22 },
  note: {
    fontSize: 13,
    color: C.faint,
    lineHeight: 19,
    paddingHorizontal: S.gutter,
    marginTop: 18,
  },
});
