import React, { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useStore } from '@/store';
import { Button, Card, Dot, Eyebrow, Screen } from '@/components/ui';
import { C, S } from '@/theme';

export default function MapSubjects() {
  const router = useRouter();
  const { subjects } = useLocalSearchParams<{ subjects: string }>();
  const list = (subjects ?? '').split('||').filter(Boolean);

  const courses = useStore((s) => s.courses);
  const subjectMap = useStore((s) => s.subjectMap);
  const setSubjectMap = useStore((s) => s.setSubjectMap);

  const [draft, setDraft] = useState<Record<string, string>>({});

  const save = () => {
    setSubjectMap({ ...subjectMap, ...draft });
    router.back();
  };

  return (
    <Screen>
      <View style={styles.head}>
        <Pressable onPress={() => router.back()} hitSlop={12}>
          <Ionicons name="close" size={30} color={C.text} />
        </Pressable>
        <Text style={styles.title}>Match subjects</Text>
      </View>

      <Card>
        <Text style={styles.body}>
          Your portal names these differently from your courses. Match them once and BunkBank will
          remember for every future report.
        </Text>
      </Card>

      {list.map((subject) => (
        <View key={subject}>
          <Eyebrow>{subject}</Eyebrow>
          <Card>
            {courses.map((c) => {
              const picked = draft[subject] === c.id;
              return (
                <Pressable
                  key={c.id}
                  onPress={() => setDraft((d) => ({ ...d, [subject]: c.id }))}
                  style={styles.option}
                >
                  <Dot color={c.color} />
                  <Text style={[styles.optionText, picked && { color: C.text }]}>{c.name}</Text>
                  {picked ? <Ionicons name="checkmark" size={22} color={C.green} /> : null}
                </Pressable>
              );
            })}
          </Card>
        </View>
      ))}

      <View style={{ paddingHorizontal: S.gutter, gap: 10 }}>
        <Button
          label="Save matches"
          onPress={save}
          disabled={Object.keys(draft).length === 0}
        />
        <Button label="Skip these rows" tone="ghost" onPress={() => router.back()} />
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  head: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    paddingHorizontal: S.gutter,
    marginBottom: 22,
  },
  title: { fontSize: 28, fontWeight: '800', color: C.text, letterSpacing: -0.6 },
  body: { fontSize: 15, color: C.dim, lineHeight: 23 },
  option: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 14,
  },
  optionText: { flex: 1, fontSize: 16, color: C.dim, fontWeight: '600' },
});
