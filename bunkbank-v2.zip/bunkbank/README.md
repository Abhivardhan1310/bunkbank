# BunkBank v2

College attendance tracker. Swipe to mark lectures, reconcile against your college's official
per-lecture report, and reshuffle days without ever changing how many lectures a course has.

## Build it into an APK

Full step-by-step instructions are in **BUILD.md**. The short version:

```bash
npm install
npm install -g eas-cli
eas login
eas init
eas build -p android --profile preview
```

Expo builds it in the cloud (~10-15 min) and gives you a download link and a QR code.

Verified in this project before shipping: dependencies resolve on Expo SDK 57,
`npx tsc --noEmit` is clean, `npx expo-doctor` passes its dependency checks, and
`npx expo export` produces a 4.5 MB Android bundle.

## The one idea worth knowing

Every course carries a fixed **lecture budget** (`course.totalLectures`). The scheduler walks
forward from the semester start day by day, spending that budget on whatever slots it meets, and
stops for a course the moment its budget hits zero.

Nothing in the app changes the budget. Everything only changes *when* it gets spent:

| Action | Effect on the walk | Effect on the tail |
|---|---|---|
| Postpone a lecture | that slot spends nothing | one more lecture appears at the end |
| Mark a day a holiday | every slot that day spends nothing | that many appear at the end |
| Add an extra lecture | budget spent early | the last lecture disappears |
| Run another weekday's timetable | several spent early | that many disappear from the end |

So the semester total is invariant by construction — there is no bookkeeping code that "moves a
lecture to the end", and no way for the count to drift. A postponed Monday lecture reappears at the
course's next free slot after its current final lecture, which is exactly "the earliest available
slot at the end of the semester".

There is deliberately **no semester end date** setting. The semester ends where the budget runs out,
and that date moves as you postpone and pull forward. Settings shows the current landing date.

The only thing allowed to change a budget is you (Course detail → Semester total) or an official
report that proves more lectures happened than were scheduled.

## Reconciling with the official report

Settings → Import attendance report. Attach the **detailed per-lecture** PDF, not the summary.

Three rules, in priority order:

1. **The report wins where it has a row** — even over a swipe you made.
2. **Your swipe stands where the report is silent.** Faculty mark late; wiping your own record
   because the portal hasn't caught up would be worse than a stale row.
3. **A row with no scheduled lecture gets inserted, and the course total goes up.** The report is
   the authority on how many lectures actually ran.

Report-sourced marks are tagged `source: 'report'` and show a lock badge in Schedule and course
history, so you can see at a glance what is official and what is yours.

Subject names rarely match your course names. The first import shows a **Match subjects** screen;
those pairings are saved in `subjectMap` and reused for every future report.

The review screen shows exactly what will change before anything is written.

## Layout

```
app/
  _layout.tsx            root stack, hydration gate, onboarding redirect
  setup.tsx              semester start
  (tabs)/
    index.tsx            Today — the swipe deck
    courses.tsx          per-course rings and bunk budgets
    schedule.tsx         week strip + day list
    settings.tsx         courses, report import, target, API key
  course/[id].tsx        stats, weekly slots, semester total, history
  day/[date].tsx         postpone, extras, clone a weekday, holidays
  import-timetable.tsx   photo/PDF -> courses
  import-report.tsx      PDF -> reconciliation
  map-subjects.tsx       report subject -> course
src/
  lib/schedule.ts        the budget walk (read this first)
  lib/stats.ts           bunk maths
  lib/report.ts          reconciliation rules
  lib/gemini.ts          Google AI Studio calls
  store.ts               zustand + AsyncStorage, rebuilds schedule on every mutation
```

## Bunk maths

At an 80% target, for a 60-lecture course with 18 attended and 6 missed:

```
needed         = ceil(0.80 × 60) = 48
must attend    = 48 − 18         = 30
bunks left     = 60 − 48 − 6     = 6
```

Both are budgets against the whole semester rather than against lectures held so far, which is why
they stay put when a lecture is postponed. This reproduces v1's displayed numbers exactly. The
target is adjustable in Settings (75 / 80 / 85).

## Known gaps

- Timetable import defaults each course to `weekly slots × 15 weeks`. Check the totals in Settings
  after importing — that's the one number the whole schedule hangs off.
- Extra lectures use a typed `HH:MM` field rather than a time picker.
- No v1 data migration.
