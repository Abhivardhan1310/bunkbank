# Building BunkBank into an APK

Two routes. **Route A** is the one to use — it's about ten minutes of setup and every build after
that is one command. **Route B** wires it to GitHub so a `git push` builds the APK for you.

Both use EAS Build, Expo's cloud build service. Your free account gets **15 Android builds a
month**, which is far more than you'll need.

---

## Route A — build from your laptop

### 1. Install Node

You need Node 20 or newer. Check what you have:

```bash
node --version
```

If it's missing or older than v20, install from https://nodejs.org (take the LTS build).

### 2. Unzip the project and install dependencies

```bash
cd path/to/bunkbank
npm install
```

Takes a couple of minutes and creates `node_modules/`. Expect a few deprecation warnings — those
are normal and come from Expo's own dependency tree.

### 3. Create an Expo account

Sign up free at https://expo.dev/signup. No card needed.

### 4. Install the EAS CLI and log in

```bash
npm install -g eas-cli
eas login
```

If `npm install -g` fails with a permissions error on macOS or Linux, use `sudo npm install -g
eas-cli`.

### 5. Link the project to your Expo account

```bash
eas init
```

It asks whether to create a project called `attendance-tracker` — say yes. This writes a project ID
into `app.json`. Commit that if you're using git.

### 6. Build

```bash
eas build --platform android --profile preview
```

Two things happen on the first run:

- **"Generate a new Android Keystore?"** → **Yes**. Expo generates and stores the signing key for
  you. Don't lose the Expo account it's tied to — Android will refuse to install an update signed
  with a different key, so a lost keystore means uninstalling before you can upgrade.
- Your code uploads and enters the build queue. Free-tier builds are low priority, so expect
  **10–25 minutes** depending on the queue.

You'll get a link like `https://expo.dev/accounts/<you>/projects/attendance-tracker/builds/<id>`.
The terminal prints a QR code too.

### 7. Install it on your phone

Open the build page on your phone and tap **Install**, or scan the QR code. Android will warn about
installing from an unknown source — allow it for your browser, then open the downloaded `.apk`.

The `preview` profile is already set to `buildType: apk`, so you get a directly installable file
rather than an AAB you'd have to go through Play Store to open.

### Rebuilding later

Just step 6 again. Bump `version` in `app.json` when you want to tell builds apart.

---

## Route B — push to GitHub, get an APK automatically

The project already contains `.github/workflows/build-apk.yml`. It typechecks, then triggers an EAS
build, on every push to `main`.

### 1. Put the code on GitHub

Create an empty **private** repo at https://github.com/new — don't add a README or .gitignore, the
project has its own. Then:

```bash
cd path/to/bunkbank
git init
git add .
git commit -m "BunkBank v2"
git branch -M main
git remote add origin https://github.com/<your-username>/bunkbank.git
git push -u origin main
```

`node_modules/` is already excluded by `.gitignore`.

### 2. Create an Expo access token

Go to https://expo.dev/settings/access-tokens → **Create token** → copy it. You only see it once.

### 3. Add it to the repo as a secret

In your GitHub repo: **Settings → Secrets and variables → Actions → New repository secret**

- Name: `EXPO_TOKEN`
- Value: the token you just copied

The name must match exactly — the workflow reads `secrets.EXPO_TOKEN`.

### 4. Run it

Do Route A steps 1–5 once first (locally), so `eas init` writes the project ID into `app.json` and
the keystore exists. Commit and push that change.

After that, every push to `main` builds automatically. You can also trigger it by hand: **Actions →
Build APK → Run workflow**.

When it finishes, the download link appears in the run's summary page, and the build is also listed
at https://expo.dev under your project.

---

## If something goes wrong

**`eas: command not found`** — the global npm bin folder isn't on your PATH. Use `npx eas-cli build
--platform android --profile preview` instead; it works without a global install.

**Build fails at "Install dependencies"** — usually a stale lockfile. Delete `package-lock.json` and
`node_modules/`, run `npm install`, commit the new lockfile, and rebuild.

**Build fails at "Run gradlew"** — open the build page and read the log; it's almost always a native
module version mismatch. `npx expo-doctor` locally will usually name the offending package, and
`npx expo install --check` will fix versions to match SDK 57.

**"App not installed" on your phone** — you have v1 installed and it's signed with a different key.
Uninstall BunkBank first. Your v1 data goes with it, so finish the current semester or export
anything you need before you do.

**Build succeeds but the app crashes on launch** — check that Settings has your Google AI Studio
key, then reproduce locally with `npx expo start` and read the error in the terminal, which is much
more informative than the crash screen.

---

## Testing without a build

While you're iterating, you don't need an APK at all:

```bash
npx expo start
```

Install **Expo Go** from the Play Store, scan the QR code, and the app runs on your phone with live
reload. The only caveats are `expo-secure-store` and the camera, which behave slightly differently
in Expo Go than in a real build — worth doing one real APK build before you trust it with a
semester's attendance.
